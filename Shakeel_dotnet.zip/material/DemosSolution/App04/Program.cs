﻿using System;
using System.Linq;

// for Form, Toolbar classes
using System.Windows.Forms;

// for MEF
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;

// for Assembly class
using System.Reflection;
using System.IO;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // to combine all catalogs
        AggregateCatalog aggcatalog = new AggregateCatalog();

        // Current EXE
        AssemblyCatalog asmcatalog = new AssemblyCatalog(Assembly.GetExecutingAssembly());
        aggcatalog.Catalogs.Add(asmcatalog);

        if (Directory.Exists("shapes"))
        {
            // Load DLLs from the Folder
            DirectoryCatalog dircatalog = new DirectoryCatalog("shapes");
            aggcatalog.Catalogs.Add(dircatalog);
        }

        // start the MEF: Discover the Classes, Create Their objects and Inject them
        CompositionContainer cc = new CompositionContainer(aggcatalog);
        cc.ComposeParts();

        IEnumerable<Form> f1 = cc.GetExportedValues<Form>("System.Windows.Forms.Form");

        if (f1.Count() != 0)
        {
            foreach (Form form in f1)
            {
                form.Show();
            }

            Application.Run();

            Application.Exit();
        }
        else

            MessageBox.Show("No Window could be created.");
    }
}
//----------------------------------------------
class Circle
{

}

[Export(typeof(ShapeFactory))]
class CircleFactory : ShapeFactory
{
    public string GetName()
    {
        return "Circle";
    }
    public object Create()
    {
        return new Circle();
    }
}
//-------------------------------------------------
class Rectangle
{

}

[Export(typeof(ShapeFactory))]
class RectangleFactory : ShapeFactory
{
    public string GetName()
    {
        return "Rectangle";
    }
    public object Create()
    {
        return new Rectangle();
    }
}
