﻿using System;

// for MEF
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;

using System.Reflection; // for Assembly class

interface I1 // can-do
{
    string FirstName { get; set; }
    string LastName { get; set; }
}

// People is loosely-coupled with Person class
class People
{
    [Import]
    public I1 p { get; set; } // internally it has reference var.

    public People()
    {
        //person = new Person();
        //person = (Person) Activator.CreateInstance(Type.GetType("Person"));
        //person.FirstName = "F1";
    }

    public void Display()
    {
        Console.WriteLine(p.FirstName + " " + p.LastName);
    }
}

class Program
{
    static void Main()
    {
        People people = new People();

        AssemblyCatalog asmcatalog = new AssemblyCatalog(Assembly.GetExecutingAssembly());

        // Start MEF
        CompositionContainer cc = new CompositionContainer(asmcatalog);
        cc.ComposeParts(people);
        // 1. Discover classes at runtime
        // 2. Create objects
        // 3. Injects their references


        people.Display();

        //Person p = new Person();
    }
}

[Export(typeof(I1))]
class Person : I1 
{
    public string FirstName { get; set; }
    public string LastName { get; set; }

    public Person()
    {
        FirstName = "F1";
        LastName = "L1";
    }
}