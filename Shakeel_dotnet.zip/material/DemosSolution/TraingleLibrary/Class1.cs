﻿using System.ComponentModel.Composition;

// Dependencies on the following DLLs:
// System.ComponentModel.Composition
// ShapeLibrary

// ----------------------------------------------
class Triangle
{

}

[Export(typeof(ShapeFactory))]
class TriangleFactory : ShapeFactory
{
    public string GetName()
    {
        return "Triangle";
    }
    public object Create()
    {
        return new Triangle();
    }
}
//--------------------------------------------------