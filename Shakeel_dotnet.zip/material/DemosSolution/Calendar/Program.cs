﻿using System;

public class Calendar
{
    private int _year;
    public Calendar(int year)
    {
        _year = year;
    }
    public void Show()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("{0,15}\n", _year);
        string[] monthNames = new string[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
        for (int month = 1; month <= 12; month++)
        {
            DateTime dt = new DateTime(_year, month, 1);
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("{0,15}\n", monthNames[month - 1]);
            Console.ForegroundColor = ConsoleColor.Yellow;
            foreach (var dayName in new string[] { "Su", "Mo", "Tu", "We", "Th", "Fr", "Sa" })
                Console.Write("{0,-3} ", dayName);
            Console.WriteLine();
            int offset = 0;
            switch (dt.DayOfWeek)
            {
                case DayOfWeek.Sunday: offset = 0; break;
                case DayOfWeek.Monday: offset = 1; break;
                case DayOfWeek.Tuesday: offset = 2; break;
                case DayOfWeek.Wednesday: offset = 3; break;
                case DayOfWeek.Thursday: offset = 4; break;
                case DayOfWeek.Friday: offset = 5; break;
                case DayOfWeek.Saturday: offset = 6; break;
            }
            for (int i = 0; i < offset; i++)
                Console.Write("    ");
            Console.ForegroundColor = ConsoleColor.Cyan;

            for (int day = 1; day <= 31; day++)
            {
                try
                {
                    DateTime d = new DateTime(_year, month, day);
                    if (d.DayOfWeek == DayOfWeek.Sunday && day != 1)
                        Console.WriteLine();
                    Console.Write("{0,-3} ", day);
                }
                catch (ArgumentOutOfRangeException)
                {
                    break;
                }
            }
            Console.WriteLine("\n\n");
        }
    }
}

class Program
{
    static void Main()
    {
        Calendar c = new Calendar(2015);
        c.Show();
    }
}
