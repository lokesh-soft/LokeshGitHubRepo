﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
class Button
{
    public event EventHandler Click; // can hold reference of delegate object
    // C# Compiler:
    // private EventHandler _click; // field
    // public void Add_Click( dr ) { sync { Delegate.Combine ( _click, dr ) ; } }
    // public void Remove_Click() {  sync { }} 
}
*/
class Program
{
    static void Main()
    {
        Form f = new Form();

        Button b1 = new Button();
        f.Controls.Add(b1);
        b1.Text = "Read Data";

        TextBox t1 = new TextBox();
        t1.Location = new Point(50, 50);
        f.Controls.Add(t1);

        ListView lv = new ListView();
        lv.Location = new Point(100, 100);
        lv.Size = new Size(300, 300);
        f.Controls.Add(lv);
        lv.View = View.Details;
        lv.Columns.Add("Id");
        lv.Columns.Add("Title");
        lv.Columns.Add("Author");
        lv.Columns.Add("Price");

        f.AutoSize = true;

        // CSC: async function => converts => State Machine class
        b1.Click += async (sender, args) => // Message Loop calls Event Handler using MT
        {
            SqlConnection connection = new SqlConnection(@"server=localhost\sqlexpress;database=abb1000;integrated security=true"); // MT

            // Prepare the query
            SqlCommand command = new SqlCommand(); // MT

            // select all records (BAD Query) => Convert it to Paging Query 
            command.CommandText = "select Id, Title, Author, Price from Books"; // MT
            command.Connection = connection; // MT

            try
            {
                // await works on those function which return task object
                // Task has 2 states: Complete and Incomplete

                // Open the Connection
                await connection.OpenAsync(); // MT (may take > 50ms)
                //connection.Open(); // MT (may take > 50ms)
                // give the work to OS (IO Completion Port) and send the MT back to message loop
                // as soon as OS completes the work, the MT comes back from message loop

                // Execute the query to obtain cursor, which helps in reading the result
                //SqlDataReader reader =  command.ExecuteReader(); // MT (may take >50 ms)
                SqlDataReader reader = await command.ExecuteReaderAsync(); // MT (may take >50 ms)
                // give the work to OS (IO Completion Port) and send the MT back to message loop
                // as soon as OS completes the work, the MT comes back from message loop

                //while (reader.Read()) // obtains 1 record at a time - MT (may take >50 ms)
                while (await reader.ReadAsync()) // obtains 1 record at a time - MT (may take >50 ms)
                // give the work to OS (IO Completion Port) and send the MT back to message loop
                // as soon as OS completes the work, the MT comes back from message loop
                {
                    // reading the data from reader
                    // convert the data to Book object
                    // Add Book object to List<Book> object

                    ListViewItem li = lv.Items.Add(reader["id"].ToString());
                    li.SubItems.Add(reader["Title"].ToString());
                    li.SubItems.Add(reader["Author"].ToString());
                    li.SubItems.Add(reader["Price"].ToString());

                    await Task.Delay(2000); // 2 secs
                    //Thread.Sleep(2000); // blocks the thread
                }

                // returning the List<Book> object
            }
            finally
            {
                connection.Close(); // MT 
            }

            MessageBox.Show("Completed");
        }; // MT returns to message loop

        // Toggle
        //EventHandler e1 = null, e2 = null;
        //// Lambda is way to write callback function (function whose address is stored in delegate object)
        //e1 = (sender, args) =>
        //                   {
        //                       MessageBox.Show("e1");
        //                       b1.Click -= e1;
        //                       b1.Click += e2;
        //                   };

        //e2 = (sender, args) =>
        //                    {
        //                       MessageBox.Show("e2");
        //                        b1.Click -= e2;
        //                        b1.Click += e1;
        //                    };
        //b1.Click += e1;


        // Multiple
        // Lambda is way to write callback function
        //b1.Click += (sender, args) =>
        //{
        //    MessageBox.Show("1st");
        //};

        //b1.Click += (sender, args) =>
        //{
        //    MessageBox.Show("2nd");
        //};

        f.ShowDialog();
    }
}