﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

// Thread-Safe Class
sealed class StackConcurrent<T>
{
    private List<T> items = new List<T>(); // having sync block index
    //private object sync = new object();

    // each object of a class contains Sync Block Index, 
    // which is initially -1
    void Push(T item)
    {
        lock (items) // acquire the lock
        {
            items.Add(item);
        } // release the lock
    }

    T Pop()
    {
        lock (items) // acquire the lock
        {
            T item = items[items.Count - 1];
            items.RemoveAt(items.Count - 1);
            return item;
        }// release the lock
    }
}
class Program
{
    static int i = 0;
    static object sync = new object();
    // each object of a class contains Sync Block Index, 
    // which is initially -1
    static void F1()
    {
        lock (sync) // acquire the lock
        {
            i++;
            Console.WriteLine("F1: " + i); // 1
            i++;
            Console.WriteLine("F1: " + i); // 2
        } // release the lock
    }
    static void F2()
    {
        lock (sync) // acquire the lock
        {
            i++;
            Console.WriteLine("F2: " + i);
            i++;
            Console.WriteLine("F2: " + i);
        }// release the lock
    }


    static AutoResetEvent ae = new AutoResetEvent(false /* not-set */);
    // ae has 2 states: not-set/not-signal and set/signal

    static void Fun1()
    {
        while (true)
        {
            ae.WaitOne(); // if ae is not-set, thread will wait on event
            // when ae goes to set state, thread will come out of wait
            // after the thread comes out of wait, ae resets to not-set state

            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine(i);
            }
        }
    }

    static ManualResetEvent me = new ManualResetEvent(false /* not-set */);

    static void Fun2()
    {
        while (true)
        {
            me.WaitOne(); // if me is not-set, thread will wait on event
                          // when me goes to set state, thread will come out of wait
                          // after the thread comes out of wait, me resets to not-set state
            me.Reset();

            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine("Fun2: " + i);
            }
        }
    }

    static void Fun3()
    {
        while (true)
        {
            me.WaitOne(); // if me is not-set, thread will wait on event
                          // when me goes to set state, thread will come out of wait
                          // after the thread comes out of wait, me resets to not-set state
            me.Reset();

            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine("Fun3: " + i);
            }
        }
    }


    static int[] items = new int[10];
    static int count = 1;
    static ReaderWriterLock rw = new ReaderWriterLock();

    static void Fill()
    {
        while (true)
        {
            ae.WaitOne();

            rw.AcquireWriterLock(Timeout.Infinite);
            for (int i = 0; i < items.Length; i++)
                items[i] = count;
            rw.ReleaseWriterLock();

            count++;

            me.Set();
        }
    }

    static void Display()
    {
        while (true)
        {
            me.WaitOne();
            me.Reset();

            rw.AcquireReaderLock(Timeout.Infinite);
            for (int i = 0; i < items.Length; i++)
            {
                Console.WriteLine(items[i]);
                Thread.Sleep(100);
            }
            rw.ReleaseReaderLock();
        }
    }

    static void Save()
    {
        while (true)
        {
            me.WaitOne();
            me.Reset();

            rw.AcquireReaderLock(Timeout.Infinite);
            using (StreamWriter writer = new StreamWriter("data.txt"))
            {
                for (int i = 0; i < items.Length; i++)
                {
                    writer.WriteLine(items[i]);
                    Thread.Sleep(100);
                }
            }
            rw.ReleaseReaderLock();

        }
    }

    static void Main()
    {
        Task.Run(() => Fill());
        Task.Run(() => Display());
        Task.Run(() => Save());


        while (true)
        {
            Console.ReadLine();
            ae.Set();
        }

        //Task.Run(() => Fun2());
        //Task.Run(() => Fun3());

        //while (true)
        //{
        //    Console.ReadLine();
        //    me.Set(); // make the me go to set state
        //}


        //Task.Run(() => F1());
        //Task.Run(() => F2());


        Console.ReadLine();
    }
}