﻿using System;
using System.Collections.Generic;
using System.Dynamic;

class Program
{
    static void Main()
    {
        var i = 10; // CSC: int i = 10 ;

        // DLR : System.Core.dll
        dynamic d = 10;
        Console.WriteLine(d);

        d = "abc";
        Console.WriteLine(d.ToUpper());

        d = DateTime.Now;
        Console.WriteLine(d.Year);

        // 1. To communicate with dynamic languages
        // IRONPython and IRONRuby

        // 2. To simplify code that is difficult to use

        dynamic x = new Sample();
        x.p1 = 100; // TrySetMember (p1, 100)
        x.p2 = 200;  // TrySetMember (p2, 200)
        x.p3 = 300;  // TrySetMember (p2, 200)
        x.p4 = 400;  // TrySetMember (p2, 200)
        Console.WriteLine(x.p1);   // TryGetMember (p1)
        Console.WriteLine(x.p2);  // TryGetMember (p2)
        Console.WriteLine(x.p3);  // TryGetMember (p2)
        Console.WriteLine(x.p4);  // TryGetMember (p2)

    }
}

class Sample : DynamicObject
{
    Dictionary<string, object> d = new Dictionary<string, object>();
    public override bool TrySetMember(SetMemberBinder binder, object value)
    {
        d.Add(binder.Name, value);
        return true;
    }
    public override bool TryGetMember(GetMemberBinder binder, out object result)
    {
        result = d[binder.Name];
        return true;
    }
}