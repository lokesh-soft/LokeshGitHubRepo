﻿using System;
using System.IO;

using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting; // extension methods (ComposeParts)
using System.Collections.Generic;
using System.Reflection;

interface IReader : IDisposable
{
}

[Export(typeof(IReader))]
public sealed class MyReader : Object, IDisposable, IReader
{
    private StreamReader reader;

    public MyReader()
            : this("data.txt")
    {
    }

    public MyReader(string filename)
    {
        reader = new StreamReader(filename); // open the file in read mode
    }

    public string[] Read(char separator)
    {
        if (reader != null)
        {
            reader.BaseStream.Seek(0, SeekOrigin.Begin);
            string data = reader.ReadToEnd();
            return data.Split(separator);
        }
        else
            throw new Exception("File is closed");
    }

    public void Close()
    {
        if (reader != null)
        {
            reader.Close();
            reader = null;
            GC.SuppressFinalize(this); // for this object GC should not call finalize method
        }
    }

    public void Dispose() // must
    {
        Close();
    }

    ~MyReader() // finalize method which is called by GC
    {
        Close();
    }
}

[Export]
sealed class Caller : IDisposable
{
    [ImportMany]
    public List<IReader> Readers { get; set; }

    public void Dispose()
    {
        foreach (var reader in Readers)
        {
            if (reader is IDisposable)
            {
                (reader as IDisposable).Dispose();
            }
        }
    }

    public void DoWork()
    {
        if (Readers != null)
        {
            foreach (var reader in Readers)
            {
                // call some method using reader
            }

        }
    }
}

class Program
{
    static void Read()
    {
        AssemblyCatalog asmcatalog = new AssemblyCatalog(Assembly.GetExecutingAssembly());
        CompositionContainer cc = new CompositionContainer(asmcatalog);
        cc.ComposeParts();

        try
        {
            Caller c = cc.GetExportedValue<Caller>();
            c.DoWork();
        }
        finally
        {
            cc.Dispose();
        }

        //try
        //{
        // try  { code } finally { mr.Dispose() ;}
        //using (MyReader mr = new MyReader("data.txt")) // opening the file

        //MyReader mr = new MyReader("data.txt");
        //{
        //    string[] arr1 = mr.Read(';');
        //    foreach (string item in arr1)
        //    {
        //        Console.WriteLine(item);
        //    }

        //    Console.WriteLine();

        //    string[] arr2 = mr.Read(',');
        //    foreach (string item in arr2)
        //    {
        //        Console.WriteLine(item);
        //    }

        //    //mr.Close();
        //}
        //}
        //catch(Exception ex)
        //{
        //    Console.WriteLine(ex);
        //}

        //MyReader mr = null;
        //try
        //{
        //    mr = new MyReader("data.txt"); // opening the file
        //    string[] arr1 = mr.Read(';');
        //    foreach (string item in arr1)
        //    {
        //        Console.WriteLine(item);
        //    }

        //    Console.WriteLine();

        //    string[] arr2 = mr.Read(',');
        //    foreach (string item in arr2)
        //    {
        //        Console.WriteLine(item);
        //    }
        //}
        //catch(Exception ex)
        //{

        //}
        //finally
        //{
        //    if (mr != null)
        //        mr.Close();
        //}

        // try {
        // opens the file in read mode
        //using (StreamReader reader = new StreamReader(@"..\..\program.cs"))
        //{

        //    string data = reader.ReadToEnd();
        //    Console.WriteLine(data);
        //    // exception here or return 

        //} // } finally { reader.Close() ; }
    }

    static void Main()
    {
        int[] numbers = { 1, 2, 3, 4, 5 };

        IEnumerable<int> en = numbers;
        using (IEnumerator<int> et = en.GetEnumerator())
        {
            while (et.MoveNext())
                Console.WriteLine(et.Current);
        }



        //Read();

        //Console.ReadLine();

        //GC.Collect(); // forcing the GC to run

        //Console.WriteLine("Press enter to exit...");
        //Console.ReadLine();
    }
}