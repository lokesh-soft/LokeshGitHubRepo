﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

// Example Unity (like MEF)

// Dependency Injection

// new : to created an object
// reflection : to create an object using Activator.CreateInstance()

// Unity
// MEF

public interface IService
{
    void Work();
}

public sealed class Service1 : IService // Implementation
{
    public void Work()
    {
        Console.WriteLine("Service1 Work");
    }
}

public sealed class Service2 : IService// Implementation
{
    public void Work()
    {
        Console.WriteLine("Service2 Work");
    }
}

class Sample1
{
    IService _s = null ;
    public Sample1(IService s)
    {
        _s = s;
    }

    public void MakeCall()
    {
        _s.Work();
    }
}

class Sample2
{
    IService _s = null;
    public Sample2(IService s)
    {
        _s = s;
    }

    public void MakeCall()
    {
        _s.Work();
    }
}

public class Program
{
    static void Main()
    {
        UnityContainer container = new UnityContainer(); // Activator.CreateInstance()

        var config = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
        config.Configure(container);


        //var s = container.Resolve<IService>();
        //s.Work();

        IService s = container.Resolve<IService>();

        Sample1 s1 = new Sample1(s);
        s1.MakeCall();

        Sample2 s2 = new Sample2(s);
        s2.MakeCall();


        //string classname = ConfigurationManager.AppSettings["classname"]; //3
        ////string classname = Console.ReadLine(); // 2
        ////IService s1 = new Service1(); // 1
        //IService s1 = (IService) Activator.CreateInstance(Assembly.GetExecutingAssembly().GetType(classname) );
        //s1.Work();
    }
}




















//public interface IService
//{
//    void Work1();
//}

//public class Service1 : IService
//{
//    public void Work1()
//    {
//        Console.WriteLine("Service1");
//    }
//}

//public class Service2 : IService
//{
//    public void Work1()
//    {
//        Console.WriteLine("Service2");
//    }
//}



//class Program
//{
//    static void Main(string[] args)
//    {
//        UnityContainer container = new UnityContainer();

//        UnityConfigurationSection config =
//        ConfigurationManager.GetSection("unity") as UnityConfigurationSection;
//        config.Configure(container);

//        //container.RegisterType<IService, Service1>();

//        IService s1 = container.Resolve<IService>();
//        s1.Work1();
//    }
//}