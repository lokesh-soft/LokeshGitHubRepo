﻿using System;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

// Object of a class should by smallest Unit-Testable Unit
class SearchLogic // SRP
{
    // Event Pattern
    public event Action<string> FolderEntered;
    public event Action<string> FileFound;
    public event Action<string> FolderDenied;
    public event Action SearchCompleted;
    //--------------------------------------------

    //public SynchronizationContext sc = null; 

    public string FileName { get; set; }

    private CancellationTokenSource cts = null;
    private Task t = null;

    public bool IsSearchRunning()
    {
        if (t == null)
            return false;
        return true;
    }

    public void StopSearch() // Main Thread
    {
        if (cts == null) // Main Thread
            throw new Exception("Task not started."); // Main Thread
        cts.Cancel(); // request for cancellation // Main Thread
    }

    public void StartSearch(string folder) // Main Thread
    {
        //if (sc == null)
        //    throw new Exception("Set the synchronization context");

        if (string.IsNullOrEmpty(FileName)) // Main Thread
            throw new Exception("FileName is not set"); // Main Thread

        cts = new CancellationTokenSource(); // Main Thread

        // -------------------------------------------------------
        t = Task.Run(() =>  // secondary Thread starts here
        {
            Search(folder); // secondary thread calls this function
            cts = null; // secondary thread returns here
            t = null;
            SearchCompleted();
        });
        // --------------------------------------------------------------
    }

    // Long-Running Activity (more than 50 ms)
    private void Search(string dir) // Secondary Thread
    {
        if (cts.IsCancellationRequested)
            return;

        int id = Thread.CurrentThread.ManagedThreadId;

        // sc.Send(state =>
        //{
        //    FolderEntered(dir); // fire the event (making callback)
        // }, null);

        FolderEntered(dir); // fire the event (making callback)


        try
        {
            if (File.Exists(Path.Combine(dir, FileName)))
            {
                // sc.Send(state =>
                //{
                FileFound(dir); // fire the event (making callback)
                //}, null);
            }

            string[] subdirs = Directory.GetDirectories(dir);
            foreach (string subdir in subdirs)
            {

                Search(subdir); // recursive call

            }
        }
        catch (Exception ex)
        {
            //sc.Send(state =>
            //{
            FolderDenied(dir); // fire the event (making callback)
            //}, null);
        }
    }

}
class MyForm : Form
{
    TextBox filename = new TextBox();
    Button start = new Button();
    Button stop = new Button();
    Label folder = new Label();
    ListBox foundfolder = new ListBox();

    public MyForm()
    {
        this.Controls.Add(filename);
        this.Controls.Add(start);
        this.Controls.Add(stop);
        this.Controls.Add(folder);
        this.Controls.Add(foundfolder);

        filename.Location = new Point(10, 10);
        start.Location = new Point(10, 50);
        stop.Location = new Point(150, 50);
        folder.Location = new Point(10, 100);
        foundfolder.Location = new Point(10, 150);

        filename.Size = new Size(200, 30);
        folder.Size = new Size(800, 30);
        foundfolder.Size = new Size(800, 300);

        start.Text = "Start";
        stop.Text = "Stop";

        this.AutoSize = true;

        stop.Enabled = false;

        start.Click += Start_Click;
        stop.Click += Stop_Click;
    }

    SearchLogic sl;

    private void Stop_Click(object sender, System.EventArgs e)
    {
        sl.StopSearch();

        stop.Enabled = false;
        start.Enabled = true;
    }


    private void Start_Click(object sender, System.EventArgs e) // Main Thread
    {
        foundfolder.Items.Clear();

        sl = new SearchLogic();

        //sl.sc = WindowsFormsSynchronizationContext.Current;
        sl.FolderEntered += Sl_FolderEntered;
        sl.FileFound += Sl_FileFound;
        sl.FolderDenied += Sl_FolderDenied;
        sl.SearchCompleted += Sl_SearchCompleted;

        sl.FileName = "data.txt";

        int id = Thread.CurrentThread.ManagedThreadId;

        sl.StartSearch(@"c:\leadows");

        stop.Enabled = true;
        start.Enabled = false;
    }

    private void Sl_SearchCompleted()
    {

        stop.Enabled = false;
        start.Enabled = true;
    }


    // Secondary Thread -----------------------
    private void Sl_FolderDenied(string dir)
    {
        if (this.InvokeRequired) // true if function is called in ST
        {
          this.Invoke(new Action(() =>
          {            // update UI 
              foundfolder.Items.Add("Not Allowed: " + dir);

          })); //
        }
        else
        {
            // update UI 

        }

    }

    private void Sl_FileFound(string dir)
    {
        this.Invoke(new Action(() =>
        {
            // update UI 
            foundfolder.Items.Add(dir);
        })); // 
    }

    private void Sl_FolderEntered(string dir)
    {
        int id = Thread.CurrentThread.ManagedThreadId;
        this.Invoke(new Action(() =>
        {

            // update UI 
            folder.Text = dir;
        })); // 
    }
    //-----------------------------------------
}
class Program
{
    static void Main()
    {
        MyForm f = new MyForm();
        f.ShowDialog();
    }
}