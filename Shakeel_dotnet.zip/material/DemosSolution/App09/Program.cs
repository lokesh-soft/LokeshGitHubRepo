﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

class AsyncDAL
{
    public IEnumerable<Task> ReadBooks()
    {
        SqlConnection connection = new SqlConnection(@"server=localhost\sqlexpress;database=abb1000;integrated security=true");

        SqlCommand command = new SqlCommand();
        command.CommandText = "select * from Books";
        command.Connection = connection;

        Console.WriteLine("Starting 1st Task");
        yield return Task.Run(() =>
        {
           connection.Open();
        });

        Console.WriteLine("Starting 2nd Task");
        yield return Task.Run(() =>
        {
            command.ExecuteReader();
        });
    }
}

class Program
{
    static IEnumerable<int> Numbers()
    {
        System.Console.WriteLine("Number Starts here...");

        System.Console.WriteLine("Before 10");
        yield return 10;
        System.Console.WriteLine("After 10");

        System.Console.WriteLine("Before 20");
        yield return 20;
        System.Console.WriteLine("After 20");

        System.Console.WriteLine("Before 30");
        yield return 30;
        System.Console.WriteLine("After 30");
    }



    static void Main()
    {
        Numbers();

        System.Console.WriteLine("For Each Starts here...");

        // foreach ( int item in en )
        // System.Console.WriteLine("Inside foreach: " + item);

        AsyncDAL dal = new AsyncDAL();

        var en = dal.ReadBooks();
        var et = en.GetEnumerator();

        Console.WriteLine("Initiate 1st Task");
        et.MoveNext();
        Task t1 = et.Current;
        t1.ContinueWith(task =>
           {

                Console.WriteLine("Initiate 2nd Task");
               et.MoveNext();
               Task t2 = et.Current;

           });

        Console.ReadLine();
    }
}