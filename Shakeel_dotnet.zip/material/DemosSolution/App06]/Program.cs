﻿//delegate int MyDel (int x, int y) ;

/* 
class MyDel 
{
    int (*FunctionPointer) ( int, int) ;
    ReferenceVariable ;
    public MyDel ( FP, RV ) 
    {
        FunctionPointer = FP;
        RV = ReferenceVariable;
    }
}
*/

using System;

class Program
{
    //int F1(/* Program this */ int x, int y)
    //{
    //    System.Console.WriteLine("F1");
    //    return x + y;
    //}

    //static int F2(int x, int y)
    //{
    //    System.Console.WriteLine("F2");
    //    return x + y;
    //}

    //static void MakeCall ( MyDel d3 /* refers to the delegate object */ )
    //{
    //    d3(90, 80); // first time will call F1 and second time will call F2
    //}

    delegate void MyDel(int number);
    delegate void MyDel2(int number1, int number2);

    static void MultiplicationTable(int number, MyDel f /* will refer to delegate object */)
    {
        for (int i = 1; i <= 10; i++)
        {
            int result = number * i;
            f(result); // making call with the help of delegate object
        }
    }
    //---------------------------------------------

    static void Fun(int number) // callback 
    {
        System.Console.WriteLine("Fun: " + number);
    }

    static void MakeCallbacks(Delegate f, params object[] args)
    {
        f.DynamicInvoke(args);
    }

    static void Main()
    {
        MakeCallbacks(new MyDel(data => System.Console.WriteLine(data)), 100);
        MakeCallbacks(new MyDel2((data1, data2) => System.Console.WriteLine(data1 + " " + data1)), 100, 200);

        int a = 10;
        //MultiplicationTable(5, new MyDel(Fun));
        MultiplicationTable(5, Fun); // new MyDel(Fun)
        MultiplicationTable(5, number => System.Console.WriteLine("Fun: " + number));
        // Lambda: callback function can also use local vars of outer function
        // => closure

        //    Program p1 = new Program();

        //    MyDel d1 = new MyDel(p1.F1); // MyDel ( F1, p1 )

        //    MyDel d2 = new MyDel(F2); // MyDel ( F1, null)

        //    MakeCall(d1); // passing reference of 1st delegate object
        //    MakeCall(d2); // passing reference of 2nd delegate object
    }
}