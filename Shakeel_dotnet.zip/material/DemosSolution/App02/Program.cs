﻿using System.Windows.Forms; // for Form, ListView, ListBox
using System.Collections.Generic; // for IEnumerable
using System.Reflection; // for PropertyInfo
using System.Drawing; // for Size and Point

using abb; // extension method created by us to work on ListView
using System.Linq; // extension methods created by MS to work on collections

class Person
{
    public string FirtName { get; set; }
    public string LastName { get; set; }
    public string Address { get; set; }
    public string PhoneNumber { get; set; }
}

class Book
{
    public string Title { get; set; } // auto-implemented: C# 3.0 language

    /* CSC converts auto-implemented property to fully-implemented property
    private string _somefieldname ; // field
    public string Title  // fully-implemented property
    {
        get { return _somefieldname ;  } // string get_Title ( )  { }
        set { _somefieldname = value ; }  // void set_Title ( string value ) { }
    }
    */

    public string Author { get; set; } // auto-implemented: C# 3.0 language

    public double Price { get; set; } // auto-implemented: C# 3.0 language
}

class Program
{
    // CSC will mark that main an entry
    // so that CLR calls it
    static void Main()
    {
        Form f = new Form(); // for window

        //Book[] books = new Book[3];
        //// array of 3 Book reference variable all contain null

        //// making reference variable refer to object
        //books[0] = new Book() { Title = "T1", Author = "A1", Price = 1000 };
        //books[1] = new Book() { Title = "T2", Author = "A2", Price = 2000 };
        //books[2] = new Book() { Title = "T3", Author = "A3", Price = 3000 };

        Person[] people = new Person[5];
        people[0] = new Person() { FirtName = "F1", LastName = "L1", Address = "A1", PhoneNumber = "111" };
        people[1] = new Person() { FirtName = "F2", LastName = "L2", Address = "A2", PhoneNumber = "222" };
        people[2] = new Person() { FirtName = "F3", LastName = "L3", Address = "A3", PhoneNumber = "333" };
        people[3] = new Person() { FirtName = "F4", LastName = "L4", Address = "A4", PhoneNumber = "444" };
        people[4] = new Person() { FirtName = "F5", LastName = "L5", Address = "A5", PhoneNumber = "555" };

     
        ListView lv = new ListView();
        lv.View = View.Details;

        lv.Size = new Size(400,400);

        f.AutoSize = true; // window take total size of child controls
        lv.DisplayItems(people);

        //lv.DisplayItems(books); 
        // converted to MyExtensions.DisplayItems(lv) by CSC
        // means static method is being called and reference of ListView object
        // is passed to it

        f.Controls.Add(lv);

        //ListBox l = new ListBox();

        //// DataSource - property - IEnumerable
        //l.DataSource = new string[] { "1", "2", "3", "4", "5", "6" };

        //f.Controls.Add(l); // make listbox child of the window

        f.ShowDialog();
    }
}