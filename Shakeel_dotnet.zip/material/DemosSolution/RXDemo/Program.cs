﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Linq;
using System.Reactive.Linq;
using System.Reactive.Concurrency;

class MyForm : Form
{
    Button start = new Button();
    ListBox imagelist = new ListBox();
    public MyForm()
    {
        start.Location = new Point(10, 10);
        start.Text = "Start";
        this.Controls.Add(start);

        imagelist.Location = new Point(10, 40);
        imagelist.Size = new Size(200, 400);
        this.Controls.Add(imagelist);

        this.AutoSize = true;

        start.Click += Start_Click;
    }

    private string[] GetPNGFiles(string path)
    {
        try
        {
            return Directory.GetFiles(path, "*.png");
        }
        catch ( Exception)
        {
            return new string[0];
        }
    }

    private string[] GetDirectories(string path)
    {
        try
        {
            return Directory.GetDirectories(path);
        }
        catch (Exception)
        {
            return new string[0];
        }
    }

    private IEnumerable<string> GetImages()
    {
        Stack<string> directories = new Stack<string>();
        directories.Push(@"c:\");
        while ( directories.Count > 0 )
        {
            string path = directories.Pop();
            foreach (var file in GetPNGFiles(path))
            {
                yield return file;
            }

            foreach (var directory in GetDirectories(path))
            {
                directories.Push(directory);
            }
        }
    }

    private void Start_Click(object sender, EventArgs e)
    {
        var observable = this.GetImages().ToObservable(Scheduler.TaskPool);

        var interval = Observable.Interval(TimeSpan.FromMilliseconds(100));

        var subscription = 
            observable
            .Zip(interval, (d,i) => d)
            .ObserveOn(WindowsFormsSynchronizationContext.Current)
            .Subscribe(image => this.imagelist.Items.Add(image));

        //foreach (var image in GetImages())
        //{
        //    Console.WriteLine(image);
        //    imagelist.Items.Add(image);
        //}
    }
}

class Program
{
    static void Main()
    {
        MyForm f = new MyForm();
        f.ShowDialog();
    }
}