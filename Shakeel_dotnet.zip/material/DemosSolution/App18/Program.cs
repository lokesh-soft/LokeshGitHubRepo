﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

// PostGres
// SQL Data Provider
// Oracle Data Provider
// OleDB Data Provider
// ODBC Data Provider

namespace App18
{
    class Program
    {
        static void Main(string[] args)
        {
            using (TransactionScope ts = new TransactionScope()) // DTC
            {
                SqlConnection connection = new SqlConnection();
                // Insert into Books
                // Insert into Orders
                // Opening OracleConnection / SqlConnection
                // Insert for Backup

                ts.Complete(); // DBs to commit
            }

            using (TransactionScope ts = new TransactionScope()) // DTC
            {
                // EF class called DbContext / open SqlConnection
                // Insert into Books
                // Insert into Orders
                // Opening OracleConnection 
                // Insert for Backup

                ts.Complete(); // DBs to commit
            }
        }
