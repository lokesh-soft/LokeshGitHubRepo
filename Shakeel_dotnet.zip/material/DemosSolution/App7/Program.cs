﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

class SearchLogic
{
    public string FileName { get; set; }

    private int _count;
    public int Count
    {
        get { return _count; }
        set { _count = value; }
    }

    public void StartSearch(string dir)
    {
        Count = 0;
        Search(dir);
    }

    private void Search(string dir)
    {
        string[] files = Directory.GetFiles(dir);

        Interlocked.Add(ref _count, files.Length) ; // synchronizes

        if ( File.Exists (Path.Combine(dir, FileName) ) )
        {
            // Display
        }
        string[] subdirs = Directory.GetDirectories(dir); // 12
        //foreach (var subdir in subdirs)
        // Multicore Programming - Parallel Programming
       Parallel.ForEach(subdirs, subdir => { // 2 cores - 2 thread - 6
            Search(subdir);
       });
    }
}

class Program
{
    static void Main()
    {
        SearchLogic sl = new SearchLogic();
        sl.FileName = "data.txt";

        Stopwatch sw = Stopwatch.StartNew();
        sl.StartSearch(@"c:\leadows");
        Console.WriteLine(sw.ElapsedMilliseconds);

        Console.WriteLine(sl.Count);

        sw.Stop();
    }
}