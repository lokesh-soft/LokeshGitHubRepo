﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Threading;
using System.Windows.Forms;
/*
class Program
{
    // Data Store
    // Function => State Machine class (Collection of Data)
    // this class implements IEnumerable and IEnumerator
    static IEnumerable<int> GetItems()
    {
        // this whole code becomes part of MoveNext() 
        Console.WriteLine("Return 10");
        yield return 10;

        Console.WriteLine("Return 20");
        yield return 20;

        Console.WriteLine("Return 30");
        yield return 30;

        Console.WriteLine("Return 40");
        yield return 40;

        Console.WriteLine("Return 50");
        yield return 50;
    }

    //static void Search(string folder)
    //{
    //    string[] files = null;
    //    try
    //    {
    //        files = Directory.GetFiles(folder, "*.png");
    //    }
    //    catch ( UnauthorizedAccessException)
    //    {
    //        Console.ForegroundColor = ConsoleColor.Red;
    //        Console.WriteLine(folder);
    //        return;
    //    }

    //    foreach (var file in files)
    //    {
    //        Console.ForegroundColor = ConsoleColor.Green;
    //        Console.WriteLine(file);
    //    }

    //    string[] dirs = Directory.GetDirectories(folder);

    //    foreach (var dir in dirs)
    //    {
    //        Search(dir);
    //    }
    //}

    static string[] GetPNGs(string dir)
    {
        try
        {
            string[] files = Directory.GetFiles(dir, "*.png");
            return files;
        }
        catch (UnauthorizedAccessException)
        {
            return new string[0];
        }
        catch (PathTooLongException)
        {
            return new string[0];
        }
    }

    static string[] GetSubDirs(string dir)
    {
        try
        {
            string[] dirs = Directory.GetDirectories(dir);
            return dirs;
        }
        catch (UnauthorizedAccessException)
        {
            return new string[0];
        }
        catch (PathTooLongException)
        {
            return new string[0];
        }
    }

    static IEnumerable<string> Search(string folder)
    {
        Stack<string> s = new Stack<string>();
        s.Push(folder); // 1st directory
        while (s.Count > 0)
        {
            string dir = s.Pop();
            string[] files = GetPNGs(dir);
            foreach (string file in files)
            {
                //Console.WriteLine(file);
                yield return file;
            }

            string[] subdirs = GetSubDirs(dir);
            foreach (string subdir in subdirs)
            {
                s.Push(subdir);
            }
        }
    }

    static void Main()
    {
        Form f = new Form();

        Button b = new Button();
        b.Text = "Get PNGs";
        f.Controls.Add(b);

        ListBox l = new ListBox();
        l.Location = new Point(10, 40);
        l.Size = new Size(600, 400);
        f.Controls.Add(l);

        f.AutoSize = true;

        b.Click += (sender, args) => // MT
        {
            // Search returns IEnumerable using ToObservable flip to IObservable
            var observable = Search(@"c:\").ToObservable(Scheduler.TaskPool); // push mode

            // to handle the pushed data subscribe to observable
            var subscription = observable
            .ObserveOn(WindowsFormsSynchronizationContext.Current)
            .Subscribe( item =>
            {
                l.Items.Add(item);
             //   Console.WriteLine("For each: " + item);
            });

            // IEnumerable and IEnumerator : pull mode
            //foreach (string item in Search(@"c:\")) // MT
            //{
            //    l.Items.Add(item);
            //    //Application.DoEvents();
            //    Console.WriteLine("For each: " + item);
            //}
        };

        f.ShowDialog();

        //foreach (int item in GetItems())
        //{
        //    Console.WriteLine("Inside Foreach: " + item);
        //}
    }
}
*/

// Observable: cold (start from beginning to end for every subscriber)
// and hot (give to data to subscriber when it subscribes)
// Publish function shifts from cold to hot
// Shifting observable from main thread to secondary thread: Scheduler.TaskPool
// to make subscripton run on main thread using ObserveOn()
/*class Program
{
    static void Main()
    {
        // Push (Subject) (cold observable)
        var observable = new int[] { 1, 2, 3, 4, 5 }.ToObservable(Scheduler.TaskPool);

        // Receives (Observer)
        var subscription1 = observable.Subscribe(i => Console.WriteLine(i));
        var subscription2 = observable.Subscribe(i => Console.WriteLine(i));

        Console.WriteLine("Main Thread waiting...");
        Console.ReadLine(); // MT is blocked
    }
}
*/

//class Program
//{
//    static void Main()
//    {
//        // Push (Subject) (cold observable)
//        var observable = Observable.Range(1, 10);

//        // Receives (Observer)
//        var subscription1 = observable.Subscribe(i => Console.WriteLine("S1: " + i));
//        var subscription2 = observable.Subscribe(i => Console.WriteLine("S2: " + i));

//        Console.WriteLine("Main Thread waiting...");
//        Console.ReadLine(); // MT is blocked
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        // Push (Subject) (cold observable)
//        var observable = Observable.Publish(Observable.Interval(TimeSpan.FromSeconds(1)));
//        observable.Connect(); // this connects all subscribers 

//        // Receives (Observer)
//        var subscription1 = observable.Subscribe(i => Console.WriteLine("S1: " + i));

//        Console.WriteLine("Hit enter for 2nd Subscription");
//        Console.ReadLine();

//        var subscription2 = observable.Subscribe(i => Console.WriteLine("S2: " + i));

//        Console.WriteLine("Main Thread waiting...");
//        Console.ReadLine(); // MT is blocked
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        // Push (Subject) (cold observable)
//        var observable = Observable.Generate(
//                                            "a", // initialization
//                                            str => str.Length < 20, // condition
//                                            str => str + "a", // incrementation
//                                            str => str); // selection/projection
//        // observable as a loop

//        // Receives (Observer/Subscriber)
//        var subscription1 = observable.Subscribe(str => Console.WriteLine( str ));


//        Console.WriteLine("Main Thread waiting...");
//        Console.ReadLine(); // MT is blocked
//    }
//}

class Program
{
    static void Main()
    {
        CancellationTokenSource cts = new CancellationTokenSource();
        // Push (Subject) (cold observable)
        var observable = Observable.Create<char>(observer =>
                            {
                                while (true)
                                {
                                    ConsoleKeyInfo keyinfo = Console.ReadKey(true);
                                    if (keyinfo.Key == ConsoleKey.X)
                                    {
                                        observer.OnCompleted(); // stop observable
                                        break;
                                    }
                                    observer.OnNext(keyinfo.KeyChar); // send to subscriber
                                }
                                return () => { };
                            });
        // observable as a loop

        // Receives (Observer/Subscriber)
        //var subscription1 = observable
        //                          .SubscribeOn(Scheduler.TaskPool)
        //                          .Subscribe(str => Console.WriteLine("S1: " + str));

        //var subscription2 = observable
        //                      .SubscribeOn(Scheduler.TaskPool)
        //                        .Subscribe(str => Console.WriteLine("S2: " + str));

        var subscription1 = observable
            //.Where(c => !("aeiou".Contains(c + "")))
            //.Skip(3)
            //.Take(5)
            //.Select(c => Char.ToUpper(c))
            //.SubscribeOn(Scheduler.TaskPool)
            .Subscribe(cw => Console.WriteLine("S1:" + cw));

        //var subscription2 = observable
        //   //.Where(c => !("aeiou".Contains(c + "")))
        //   //.Skip(3)
        //   //.Take(5)
        //   //.Select(c => Char.ToUpper(c))
        //   //.SubscribeOn(Scheduler.TaskPool)
        //   .Subscribe(cw => Console.WriteLine("S2:" + cw));



        Console.WriteLine("Main Thread waiting...");
        //Console.ReadLine(); // MT is blocked

        new AutoResetEvent(false).WaitOne();
    }
}


//class Program
//{
//    class MyObserver<T> : IObserver<T>
//    {
//        public void OnCompleted()
//        {
//            Console.WriteLine("Completed");
//        }

//        public void OnError(Exception error)
//        {
//            Console.WriteLine("Error");
//        }

//        public void OnNext(T value)
//        {
//            Console.WriteLine("Next: " + value);
//        }
//    }
//    static void Main()
//    {
//var observable = Observable.Empty<int>();
//var observable = Observable.Return(1000);
//var observable = Observable.Range(1, 10);
//var observable = Observable.Generate(
//    "a",
//    str =>str.Length <20,
//    str => str + "a",
//    str =>str );
//var observable = new string[] { "jan", "feb", "mar" }.ToObservable();
//var observable = Observable.Create<char>(
//    observer =>
//    {
//        while (true)
//        {
//            ConsoleKeyInfo keyinfo = Console.ReadKey(true);
//            if (keyinfo.Key == ConsoleKey.X)
//            {
//                observer.OnCompleted();
//                break;
//            }
//            observer.OnNext(keyinfo.KeyChar);
//        }

//        return () => { };
//    });

////var subscription = observable.Subscribe(new MyObserver<int>());
////var subscription = observable.Subscribe(new MyObserver<string>());
//var subscription = observable
//    .Where(c => !("aeiou".Contains(c + "")))
//    .Skip(3)
//    .Take(5)
//    .Select(c => Char.ToUpper(c))
//    .SubscribeOn(Scheduler.TaskPool);
//    //.Subscribe(new MyObserver<char>());

//Console.WriteLine("Main Thread waiting...");
////Console.ReadLine();
//new AutoResetEvent(false).WaitOne();


//var observable = Observable.Interval(TimeSpan.FromSeconds(1));
//var observable = Observable.Publish(Observable.Interval(TimeSpan.FromSeconds(1)));
//observable.Connect();

//var subscription = observable.Subscribe(new MyObserver<long>());

//Console.WriteLine("Main Thread waiting...");
//Console.ReadLine();

//var subscription2 = observable.Subscribe(new MyObserver<long>());

//Console.WriteLine("Main Thread waiting...");
//Console.ReadLine();

//subscription2.Dispose();

//Console.WriteLine("Main Thread waiting...");
//Console.ReadLine();
//    }
//}
