﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security;

namespace abb
{
    [Serializable]
    public sealed class StackFullException : Exception
    {
        public StackFullException()
        {
        }
        public StackFullException(string message) : base(message)
        {
        }
    }

    [Serializable]
    public sealed class StackEmptyException : Exception
    {
        public StackEmptyException()
        {
        }
        public StackEmptyException(string message) : base(message)
        {
        }
    }


    [Serializable]
    public sealed class Stack<T> : IStack<T> // implementation 
    {
        private T[] items = new T[100];
        private int top = 0;

        public void Push(T item)
        {
            if (top < items.Length)
            {
                items[top] = item;
                top++;
            }
            else
                throw new StackFullException("Stack Full");
        }

        public T Pop()
        {
            if (top > 0)
            {
                top--;
                return items[top];
            }
            else
                throw new StackEmptyException("Stack Empty");
        }
    }


}

class Program
{
    static void SerializeDemo()
    {
        //abb.Stack<double> s = new abb.Stack<double>();
        //s.Push(10.5);
        //s.Push(20.5);
        //s.Push(30.5);
        //Console.WriteLine(s.Pop()); // 30.5

        // try { our code } finally { fs.Close() ; }
        //using (FileStream fs = new FileStream("data.bin", FileMode.Create))
        //{
        //    BinaryFormatter bf = new BinaryFormatter(); // to binary format specific: .NET
        //    bf.Serialize(fs, s);
        //    // Serialization: Converting the object in memory to some format
        //    // so that object can be reconstructed back in memory by reading
        //    // that format

        //    // After the object is serialized to any format it can be writte to
        //    // the file and any other data store
        //}

        // Serialization: 
        // XML Serialization: reconstruct the object back any platf./lang. object
        // XmlSerializer class

        // JSON Serialization: reconstruct the object back any platf./lang. object
        // Newtonsoft.json.dll

    }

    static void DeserializeDemo()
    {
        if (File.Exists("data.bin"))
        {
            try
            {
                using (FileStream fs = new FileStream("data.bin", FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    abb.Stack<double> s = (abb.Stack<double>)bf.Deserialize(fs);
                    Console.WriteLine(s.Pop()); // 20.5  
                }
            }
            catch (SecurityException ex)
            {
                // log the exception
                throw ex;
            }
            catch (abb.StackEmptyException ex)
            {
                // log
                throw ex;
            }
            catch (SerializationException ex)
            {
                // log
                throw ex;
            }
            catch (Exception ex)
            {
                // log
            }
        }
        else
        {
            // log the exception
            throw new FileNotFoundException("data.bin : not found");
        }
    }

    static void CodeIndependentOfStackImplementation(abb.IStack<double> s)
    {
        s.Push(10.5);
        s.Push(20.5);
        s.Push(30.5);
        s.Push(40.5);
        s.Push(50.5);
        Console.WriteLine(s.Pop());
    }


    class StackVerNew<T> : abb.IStack<T>
    {
        public void Push(T item)
        {
            Console.WriteLine(item);
        }
        public T Pop()
        {
            Console.WriteLine("Pop");
            return default(T);
        }
    }
}


namespace abb // Developer - 1
{

    public interface ISample<in T1,in T2, out T3, out T4>
    {
        void F1(T1 item);
        void F2(T2 item);

        T3 F3();
        T4 F4();
    }

    // Interface needs to designed to hide all Stack Implementations
    public interface IStack<in TPass, out TReturn> // Base
    {
        // will be used to call implementation 
        // and pass the object
        // by the caller (may pass Base class object)
        // implementation may work (Derived class)
        void Push(TPass item); // calling and pass Base type obejct

        // will be used to call implementation 
        // and collection the object
        // by the caller (may collect in Base class)
        // implementation may work (Derived class)
        TReturn Pop();
    }

    public class Base // Developer - 1
    {

    }

    public class Helper // Developer - 1
    {
        public static void Work1(abb.IStack<Base, Base> a1)
        {
            a1.Push(new Base()); // calling the implementation
            Base b = a1.Pop(); // calling the implementation
        }
    }
}

namespace abb // Developer - 2
{
    public class Der : Base
    {
    }

    /// <summary>
    /// TCollect can be the same type as TReturn or TCollect can be the derived type of TReturn
    /// </summary>
    /// <typeparam name="TCollect"></typeparam>
    /// <typeparam name="TReturn"></typeparam>
    [Serializable] // T :Der
    public sealed class StackNew<TCollect /* in */,TReturn /* out */> : abb.IStack<TCollect, TReturn> where TCollect : class where TReturn : class  // Developer - 2
    {
        private List<TCollect> items = new List<TCollect>();

        public StackNew()
        {
            if ( !(typeof(TCollect) is TReturn) )
            {
                throw new Exception("TCollect is not same or derived of TReturn");
            }
        }

        public void Push(TCollect item) // T: Der
        {
            items.Add(item);
        }

        public TReturn Pop()
        {
            if (items.Count == 0)
                throw new StackEmptyException("Stack Empty");

            TReturn item =  items[items.Count - 1] as TReturn ;

            if (item == null)
                throw new Exception("TCollect is not same or derived of TReturn");

            items.RemoveAt(items.Count - 1);
            return item;
        }
    }
}

static void Main() // Developer - 2
{
    abb.Helper.Work1(new abb.StackNew<abb.Base, abb.Der>());


    //abb.StackNew<abb.Der> s1impl = new abb.StackNew<abb.Der>();

    abb.Base p1 = new abb.Der(); // base p1 = new Derived();


    abb.IStack<abb.Base  /* pass */, abb.Base  /* collect */> s1 
        = new abb.StackNew<abb.Base /* collect */, abb.Der  /* return */>();

    abb.IStack<abb.Base /* pass */, abb.Base /* collect */> s2 
        = new abb.StackNew<abb.Base /* collect */, abb.Base /* return */>();

    abb.IStack<abb.Der /* pass */, abb.Base /* collect */> s3
        = new abb.StackNew<abb.Base /* collect */, abb.Base /* return */>();

    abb.IStack<abb.Der /* pass */, abb.Base /* collect */> s4
        = new abb.StackNew<abb.Der /* collect */, abb.Base /* return */>();

    //abb.Helper.Work1(s1impl);

    //s1impl.Push(new abb.A());
    //s1impl.Push(new abb.A());
    //abb.A item = s1impl.Pop();

    //Console.WriteLine();
    //CodeIndependentOfStackImplementation( new abb.Stack<double>() );

    //Console.WriteLine();
    //CodeIndependentOfStackImplementation( new abb.StackNew<double>() );

    //Console.WriteLine();
    //CodeIndependentOfStackImplementation( new StackVerNew<double>() );

    // Stack, StackNew

    //DeserializeDemo();
}
}