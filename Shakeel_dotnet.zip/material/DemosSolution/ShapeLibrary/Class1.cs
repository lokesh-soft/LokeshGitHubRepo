﻿
public interface ShapeFactory
{
    string GetName();
    object Create();
}