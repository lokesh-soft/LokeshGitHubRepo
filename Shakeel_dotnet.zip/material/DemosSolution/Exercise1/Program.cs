﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reactive.Linq;

namespace abb
{
    [Serializable]
    public sealed class SinglyLinkedList<T> : IEnumerable<T>
    {
        [Serializable]
        private sealed class Node // nested class (data Type)
        {
            public T _data;
            public Node _next = null;

            public Node() { }

            public Node(T data)
            {
                _data = data;
            }
        }

        private int _count = 0;  // instance data member of SinglyLinkedList
        private Node _head = null, _last; // instance data members of SinglyLinkedList

        public void Add(T item)
        {
            if (_head == null)
                _head = _last = new Node(item);
            else
            {
                _last._next = new Node(item);
                _last = _last._next;
            }
            _count++;
        }

        public void AddRange(params T[] items)
        {
            foreach (T item in items)
            {
                Add(item);
            }
        }

        sealed class SinglyLinkedListIterator : IEnumerator<T>
        {
            Node _head, _current;

            public SinglyLinkedListIterator(Node head)
            {
                _head = head;
            }

            public bool MoveNext() // called by foreach in loop
            {
                if (_head == null)
                    return false;
                else
                {
                    _current = _head;
                    _head = _head._next;
                    return true;
                }
            }

            public T Current // called by foreach in loop after calling MoveNext() => true
            {
                get
                {
                    return _current._data;
                }
            }

            public void Dispose()
            {
            }

            public void Reset()
            {
            }

            object IEnumerator.Current
            {
                get
                {
                    throw new NotImplementedException();
                }
            }

        }

        // called by foreach to obtain an object that helps in 
        // traversing the linked list
        public IEnumerator<T> GetEnumerator() // generic
        {
            return new SinglyLinkedListIterator(_head);
        }

        IEnumerator IEnumerable.GetEnumerator() // old
        {
            throw new NotImplementedException();
        }

        public int Count
        {
            get
            {
                return _count;
            }
        }
    }
}
class Program
{
    static void Main()
    {
        abb.SinglyLinkedList<int> l = new abb.SinglyLinkedList<int>();

        l.Add(100);
        l.Add(200);
        l.Add(300);
        l.Add(400);
        l.Add(500);
        l.AddRange(600, 700, 800, 900);
        l.AddRange(1000, 1100);

        System.Console.WriteLine(l.Count); // 5

        foreach (int item in l)
            System.Console.WriteLine(" Foreach : " + item); // 100 ... 500

        // from pull to push (may be on secondary thread)
        var observable = l.ToObservable();

        var subscription = observable
                             .Subscribe(item => Console.WriteLine("S: " + item));
    }
}