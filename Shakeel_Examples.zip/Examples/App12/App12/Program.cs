﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App12
{
    class Program
    {
        static Tuple<int, int> F1()
        {
            return Tuple.Create(2015, 11);
        }

        static Tuple<int, int> F2()
        {
            return Tuple.Create(11, 25);
        }

        static Tuple<int, int, int> F3()
        {            
           return Tuple.Create(2015, 11, 25);
        }

        static Tuple<int, int, int, int> F4()
        {            
           return Tuple.Create(2015, 11, 25, 12);
        }

        static Tuple<int, int, int,int,int,string> F5()
        {            
          return Tuple.Create(2015, 11, 25,12, 20, "Wed");
        }

        static void Main()
        {
            var t1 = F5();

            var yr = t1.Item1;
            var mn = t1.Item2;
            var dy = t1.Item3;
        }
    }
}
