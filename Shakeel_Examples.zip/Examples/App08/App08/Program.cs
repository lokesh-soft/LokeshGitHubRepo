﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App08
{    

    class Program
    {
        static void Main()
        {
            Form f = new Form();
            Button b1 = new Button();
            f.Controls.Add(b1);
            b1.Text = "Read Data";

            //CSC: async function => converts => State machine class
            b1.Click += async (sender, args) => //Msg loop calls event handler using MT
            {
                SqlConnection connection = new SqlConnection(@"server=");

                //prepare the query
                SqlCommand command = new SqlCommand();

                //select all records (BAD query) => convert it into paging query
                command.CommandText = "select * from books";
                command.Connection = connection;

                try
                {
                    //Open the connection
                    await connection.OpenAsync(); //MT takes more than 50 sec
                    //Note : give the work to OS (IO completion port) and send the MT back to message loop
                    //as soon as OS completes the work, the MT come back from the msg loop

                    //Note : Execute the query to obtain cursor, which helps in reading the result
                    SqlDataReader reader = await command.ExecuteReaderAsync();
                    ////give the work to OS (IO completion port)

                    //Note : give the work to OS (IO completion port)
                    while (await reader.ReadAsync()) //obtain 1 record at a time - MT (may take > 50 ms)
                    {
                        
                    }
                }
                finally
                {
                    connection.Close();//MT
                }

            };//MT returns to message loop

            //Toggle
            //EventHandler e1 = null, e2 = null;
            //e1 = (sender, args) =>
            //    {
            //        MessageBox.Show("e1");
            //        b1.Click -= e1;
            //        b1.Click += e2;
            //    };

            //     e2 = (sender, args) =>
            //    {
            //        MessageBox.Show("e2");
            //        b1.Click -= e2;
            //        b1.Click += e1;
            //    };

            //    b1.Click += e1;

            //Multiple deligates
            ////Lambda is a way to write a callback function
            //b1.Click += (sender, args) =>
            //{
            //    MessageBox.Show("1st");
            //};

            //b1.Click += (sender, args) =>
            //{
            //    MessageBox.Show("2nd");
            //};

            f.ShowDialog();
        }
    }
}
