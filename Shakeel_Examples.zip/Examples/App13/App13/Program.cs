﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App13
{
    class Stack
    {
        public void Push(T item)
        {
            if (top < items.Length)
            {
                items[top] = item;
                top++;
            }
            else
            {

            }
        }

        public int Pop()
        {
        }
    }

    class Program
    {
        static void Main()
        {
        }
    }
}
