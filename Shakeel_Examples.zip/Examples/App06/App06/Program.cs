﻿

using System;
namespace App06
{    
    //delegate int MyDel(int num);

    /*
     Class MyDel
     * {
     * functionPointer;
     * ReferenceVariable;
     * 
     * public MyDel(FP, RV)
     * {
     * FunctionPointer = FP;
     * RV = ReferenceVariable;
     * }
     * }
     * */
    class Program
    {
        //int F1(/*Program this */int x, int y)
        //{
        //    return x + y;
        //}

        //static int F2(int x, int y) //this does not contain address
        //{
        //    return x + y;
        //}

        //static void MakeCall(MyDel d3 /*  referes to the delegate object */)
        //{
        //    d3(80, 90);//First time call F1 and secnd time call f2
        //}

        delegate void MyDel(int number);
        delegate void MyDel2(int x, int y) ;
        static void MultiplicationTable(int number, MyDel f /* f will refrer to a delegate object */)
        {
            for (int i = 1; i <= 10; i++)
            {
                int result = number * i;
                f(result);
            }
        }

        static void Fun(int number)
        {
            System.Console.WriteLine("Fun : " + number);
        }

        static void MakeCallBacks(Delegate f, params object[] args)
        {
        }

        static void Main(string[] args)
        {

            MakeCallBacks(new MyDel(data => System.Console.WriteLine(data)), 100);
            //MakeCallBacks(new MyDel((data1, data2) => System.Console.WriteLine(data1)), 100);

            //MultiplicationTable(5, new MyDel(Fun));
            MultiplicationTable(5, Fun); //new MyDel(Fun))
            MultiplicationTable(5, number => System.Console.WriteLine("Fun :" + number));//Everey Lambda automatically becomes a  callback function
            //Lambda : Callback function can also use local vars of outer function
            //this concept is called =>Clousure
            

           // MultiplicationTable(5, Fun);//new MyDel(Fun)

            //Program p1 = new Program();
            //MyDel d1 = new MyDel(p1.F1); //MyDel(F1, p1)
            //MyDel d2 = new MyDel(F2); //MyDel(F1, null)

            //MakeCall(d1);//passing reference of first delegate object
            //MakeCall(d2);//passing reference of second delegate object
        }
    }
}
