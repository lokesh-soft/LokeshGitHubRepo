﻿using System.Collections.Generic;
using System.Windows.Forms;
using System.Reflection;
using System.Drawing;//for size and point
using System.Collections.Generic;

namespace abb
{
    public static class MyExtensions
    {
        //When VS see this before ListView name in the first parameter
        //VS makes  it appear as part of ListView but it is not a part of ListView
        //hence it cannot access private members
        //extension method - only C# lang - CLR doesent undestand it
        //C# 3.0
        public static void DisplayItems<T>(this ListView lv, IEnumerable<T> collection)
        {
            PropertyInfo[] properties = null;
            //At runtime discover properties of objects - reflection           
            foreach (T item in collection)
            {
                properties = item.GetType().GetProperties();

                foreach (PropertyInfo pi in properties)
                {
                    lv.Columns.Add(pi.Name);
                }
                break;
            }

            if (properties != null)
            {
                foreach (T item in collection)
                {
                    ListViewItem li = null;
                    foreach (PropertyInfo pi in properties)
                    {
                        if (li == null)
                        {
                            li = new ListViewItem();
                            li.Text = pi.GetValue(item).ToString();
                            lv.Items.Add(li);
                            //lv.Columns.Add(pi.Name); 
                        }
                        else
                        {
                            li.SubItems.Add(pi.GetValue(item).ToString()); //data for other columns
                        }
                    }
                }
            }
        }
    }
}
