﻿

namespace App01
{
    class Program : System.Object //mscorelib.dll
    {
        //CSC marks the naib as the entry point
        //so that CLR calls it
        static void Main(string[] args)
        {
            int i = 10; //int - system.INt32 - mscorelib.dll
            string s = "Hello";//Syste.Console class - mscorelib.dll
            System.Console.WriteLine(i); //Syste.Console class - mscorelib.dll
            System.Console.WriteLine(s); //Syste.Console class - mscorelib.dll
        }
    }
}
