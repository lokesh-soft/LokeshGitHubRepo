﻿using System.Collections.Generic;
using System.Windows.Forms;
using System.Reflection;
using System.Drawing;//for size and point
//using abb; //extension method created by US to work on ListView
using System.Linq; //Extension methods created by MS to work on collections

namespace ConsoleApplication1
{
    class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; }
    }


    class Book
    {
        public string Title { get; set; }//auto - implemented

        /* CSC converts auto-implemented property to fully implemented property
         private string _somefieldname ; //field
         public string Title //property
         {
         get { return _somefieldname;} //string get_Title () {}
         set {_somefieldname = value;} // void set_Title (string value){}
         */
        public string Author { get; set; }
        public int Price { get; set; }       

    }

 

    class Program
    {
        static void Main(string[] args)
        {
            Form f = new Form();

            Book[] books = new Book[3];
            //array of 3 book reference varaiable al contain null

            books[0] = new Book() { Title = "T1", Author = "A1", Price = 1000 };
            books[1] = new Book() { Title = "T2", Author = "A2", Price = 2000 };
            books[2] = new Book() { Title = "T3", Author = "A3", Price = 3000 };

            ListView lv = new ListView();
            lv.View = View.Details;

            lv.Size = new Size(400, 400);
            f.AutoSize = true; //window take total size of child controls
            //lv.DisplayItems(books);//converted to MyExtensions.DisplayItems(lv) by CSC , it adjust to any type of objects coz of generic or any type of collection coz of Ienumerable
            //means ststicmethod is being called reference ListView object
            //is passed to it
            f.Controls.Add(lv);

            //ListBox l = new ListBox();

            ////Datasource of type IEnumerable
            //l.DataSource = new int[] { 1, 2, 3, 4, 5,6,7,8 };
            //f.Controls.Add(l);
            f.ShowDialog();
            
        }
    }
}
