﻿
using System;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App05
{
    class SearchLogic
    {
        public event Action<string> FolderEntered;
        public event Action<string> FileFound;
        public event Action<string> FolderDenied;

        public string FileName {get; set; }

        private CancellationTokenSource cts = null;
        private Task t = null;

        public bool isSearchRunning()
        {
            if (t == null)
                return false;

            return true;            
        }

        public void Stopsearch()
        {
            if (cts == null)
            {
                throw new Exception("Filename is not set");
            }
            cts.Cancel();
        }

        public void StartSearch(string folder)
        {
            if(string.IsNullOrEmpty(FileName))
            {
                throw new Exception("FileName is not set");
            }

            cts = new CancellationTokenSource();

            Task.Run(() => //Secondary thread from different object
                {
                    Search(folder);
                    cts = null;
                });
        }

        private void Search(string dir)
        {
            if(cts.IsCancellationRequested)
                return;

            //folder.Text =dir;
            try
            {
            if(File.Exists(Path.Combine(dir, FileName)))
            {
                //foundfolder.Items.Add(dir);
            }

            string[] subdirs = Directory.GetDirectories(dir);

            foreach(string subdir in subdirs)
            {
                Search(subdir);//recursive call
            }
                
            }
            catch
            {
                //foundfolder.Items.Add("Not allowed" + dir);
            }
        }

    }

    class MyForm : Form
    {
        TextBox filename = new TextBox();
        Button start = new Button();
        Button stop = new Button();
        Label folder = new Label();
        ListBox foundfolder = new ListBox();

        public MyForm()
        {
            this.Controls.Add(filename);
            this.Controls.Add(start);
            this.Controls.Add(stop);
            this.Controls.Add(folder);
            this.Controls.Add(foundfolder);

            filename.Location = new Point(10, 10);
            start.Location = new Point(10, 50);
            stop.Location = new Point(150, 50);
            folder.Location = new Point(10, 100);
            foundfolder.Location = new Point(10, 150);

            filename.Size = new Size(200, 30);
            folder.Size = new Size(800, 100);
            foundfolder.Size = new Size(800, 300);

            start.Text = "Start";
            stop.Text = "Stop";

            this.AutoSize = true;
            stop.Enabled = false;

            start.Click += start_Click;
            stop.Click += stop_Click;
        }



            //void StartSearch()
            //{
            //    SearchLogic s1 = new SearchLogic();
            //    s1.FileName = filename.Text;                
            //    Search(@"C:\");
            //}

        SearchLogic s1 = new SearchLogic();

            void stop_Click(object sender, System.EventArgs e)
            {
                stop.Enabled = true;
                start.Enabled = false;

                //Task.Run(new Action(StartSearch));//Storing adress of the function in the deleate object
                ////and passing reference of the delegate object to Run()

               
            }

            void start_Click(object sender, System.EventArgs e)
            {
                s1 = new SearchLogic();
                s1.FolderEntered +=s1_FolderEntered;
                s1.FileFound += s1_FileFound;
                s1.FolderDenied += s1_FolderDenied;

                stop.Enabled = true;
                start.Enabled = false;

               
            }

            void s1_FolderDenied(string obj)
            {
                throw new NotImplementedException();
            }

            void s1_FileFound(string obj)
            {
                throw new NotImplementedException();
            }

            void s1_FolderEntered(string obj)
            {
    
 	            throw new NotImplementedException();
            }


        //private void InitializeComponent()
        //{
        //    this.SuspendLayout();
        //    // 
        //    // MyForm
        //    // 
        //    this.ClientSize = new System.Drawing.Size(284, 262);
        //    this.Name = "MyForm";
        //    this.Load += new System.EventHandler(this.MyForm_Load);
        //    this.ResumeLayout(false);

        //}

        //private void MyForm_Load(object sender, EventArgs e)
        //{
        
        //}

        
        

        //private void InitializeComponent()
        //{
        //    this.SuspendLayout();
             
        //     MyForm
             
        //    this.ClientSize = new System.Drawing.Size(284, 262);
        //    this.Name = "MyForm";
        //    this.Load += new System.EventHandler(this.MyForm_Load);
        //    this.ResumeLayout(false);

        //}

        //private void MyForm_Load(object sender, System.EventArgs e)
        //{

        //}
    }

    class Program
    {
        static void Main(string[] args)
        {
            Form f = new Form();

            f.ShowDialog();

        }
    }
}
