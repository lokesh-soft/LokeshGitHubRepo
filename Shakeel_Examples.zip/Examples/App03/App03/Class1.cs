﻿
using System;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Reflection;

interface I1
{
    public string FirstName { get; set; }
    public string LasttName { get; set; }
}

namespace App03
{
    class People
    {
        [Import]
        //public person person { get; set; } //internally it has a refernce var

        public I1 p { get; set; } 

        //People is loosly coupled
        public People()
        {
            //person = new Person();
            //person = (person)Activator.CreateInstance(Type.GetType("Person"));
            //person.FirstName = "F1";
        }

        public void Display()
        {
            Console.WriteLine(p.FirstName + "" + p.LastName);
        }
    }
    public class Program
    {
        static void Main()
        {
            People people = new People();
            AssemblyCatalog asm = new AssemblyCatalog(Assembly.GetExecutingAssembly());

            //Discover the classes, createa objects and injects wherever we needed
            //MEF can discover the classes of export attributes
            //MEF can injects the classes of import attributes
            CompositionContainer cc = new CompositionContainer(asm);
            cc.ComposeParts(people);

            //1. Discover the classes at runtime
            //2. Creates objects
            //3. Injects their references

            
            people.Display();
            //person p = new person();
        }
    }

    [Export(typeof(I1))]
    class person : I1
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public person()
        {
            FirstName = "F1";
            LastName = "L1";
        }
    }
}
