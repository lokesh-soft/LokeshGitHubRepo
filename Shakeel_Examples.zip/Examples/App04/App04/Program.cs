﻿using System;
using System.Windows.Forms;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Reflection;
using ShapeLibrary;
using System.IO;

namespace App04
{
    [Export(typeof(Form))]
    class MyForm : Form
    {
        //This needs reference of factory objects
        [ImportMany]
        public ShapeFactory[] Factories { get; set; }
        public MyForm()
        {
            this.Load += MyForm_Load;
        }

        //ShowDialog calls this
        void MyForm_Load(object sender, EventArgs e)
        {
            ToolBar tb = new ToolBar();

            foreach (ShapeFactory factory in Factories)
            {
                tb.Buttons.Add(factory.GetName());
            }

            this.Controls.Add(tb);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // MyForm
            // 
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Name = "MyForm";
            this.Load += new System.EventHandler(this.MyForm_Load_1);
            this.ResumeLayout(false);

        }

        private void MyForm_Load_1(object sender, EventArgs e)
        {

        }
    }

    class Program
    {
        static void Main()
        {

            AggregateCatalog aggCatalog = new AggregateCatalog();
            //Currec
            AssemblyCatalog asmcatalog = new AssemblyCatalog(Assembly.GetExecutingAssembly());           
            aggCatalog.Catalogs.Add(asmcatalog);
            

            if (Directory.Exists("shapes"))
            {
                DirectoryCatalog dircatalog = new DirectoryCatalog("shapes");
                aggCatalog.Catalogs.Add(dircatalog);
            }

            Form form = new Form();
            //1. Memory is allocated
            // 2. Ctor will be called

            //Discover classes, create their objects and injects them
            CompositionContainer cc = new CompositionContainer(aggCatalog);
            cc.ComposeParts(form);
            cc.GetExport<Form>("System.Windows.Forms.Form");

            //ToolBar tb = new ToolBar();
            //tb.Buttons.Add("Circle");
            //tb.Buttons.Add("Rectangle");
            //tb.Buttons.Add("Triangle");
            //form.Controls.Add(tb);

            form.ShowDialog();
        }
    }

    class Circle
    {
    }

    [Export(typeof(ShapeFactory))]
    class CircleFactory : ShapeFactory
    {
        public string GetName()
        {
            return "Circle";
        }

        public object Create()
        {
           return new Circle();
        }
    }
    
    class Rectangle
    {
    }

    [Export(typeof(ShapeFactory))]
    class RectangleFactory : ShapeFactory
    {
        public string GetName()
        {
            return "Rectangle";
        }

        public object Create()
        {
            return new Rectangle();
        }
    }


}
