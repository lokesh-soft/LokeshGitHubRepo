﻿using System;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace App07
{
    class searchLogic
    {
        public string FileName { get; set; }

        private int _count;
        public int Count
        {
            get { return _count; }
            set { _count = value; }
        }

        public void StartSearch(string dir)
        {
            Count = 0;
            Search(dir);
        }


        public void Search(string dir)
        {
            string[] files = Directory.GetFiles(dir);

            //Interlocked

            //Count += files.Length;

            if (File.Exists(Path.Combine(dir, FileName)))
            {
            }
            string[] subdirs = Directory.GetDirectories(dir);

            //foreach (var subdir in subdirs)
            //{
            //    Search(subdir);
            //}

            Parallel.ForEach(subdirs, subdir =>
            {
                Search(subdir);
            });

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            System.Diagnostics.Stopwatch sw = Stopwatch.StartNew();

            searchLogic s1 = new searchLogic();
            s1.Search(@"c:\");

            Console.WriteLine(sw.ElapsedMilliseconds);

            Console.WriteLine(s1.Count);
            sw.Stop();

        }
    }
}
