﻿
using System;
using System.Collections.Generic;
namespace App10
{

    static class MyExtensions
    {
        //class where_0 : IEnumerabble<int>, IEnumeratior<int> {Getenumerator() {} MoveNext() {},
        public static IEnumerable<T> Where(this IEnumerable<T> collection, Func<T, bool> condition)
        {
            Console.WriteLine("Inside where");
            foreach (T item in collection)            
                if (condition(item))//Calling callback function
                    yield return item;//current  value returned by object that implements IEnumerable<> and IEnumerator<>
            
        }

        public static IEnumerable<TReturn> Select<T, TReturn>(this IEnumerable<TReturn> collection, Func<TReturn, string> projection)
        {
            Console.WriteLine("Inside select");
            foreach (TReturn item in collection)
                yield return projection(item);
        }
    }

    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Price { get; set; }
        
    }

    class Program
    {
        static void Main()
        {
            Book[] books = {
                                new Book() {Title = "T1", Author ="A1", Price = 1000},
                                    new Book() {Title = "T2", Author ="A2", Price = 2000},
                                        new Book() {Title = "T3", Author ="A3", Price = 3000}
                            };

            IEnumerable<string> query = from book in books
                                        where book.Author == "A2" //condition
                                        select book.Price; //projection

            foreach (int price in query)
                Console.WriteLine(price);


            //array implements IEnumerable<int>
            //int[] numbers = {10, 20, 30, 40, 50};

            //preparing the query
            //IEnumerable<string> query = numbers.Where(v => v > 30).Select(v.ToString());
            //IEnumerable<string> query = from v in numbers
            //                          where v > 30 //condition
            //                          select v.ToString(); //projection
            // 2objects are created where object and select object
            //select object holds the refrence of where object and 
            //where object holds the reference of Array

            //execute the query
            //foreach (string item in query)
            //    Console.WriteLine(item);

            //query => select object => where object => array object
            //IEnumerator<string> et = query.GetEnumerator(); //all objects state gets initialize initialized
            //while (et.MoveNext()) // => select.MoveNext => where:MoveNext => Array:MoveNext
            // et.Current ; => Select:(Current =>
        }
    }
}
