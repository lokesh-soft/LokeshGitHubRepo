﻿using System;
using System.Linq.Expressions;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

namespace App11
{
    class Program
    {
        static void Main()
        {
            //Lambda
            Action<int> a1 = i => Console.WriteLine(i);

            //Lambbda
            Func<int, int, int> a2 = (i, j) => i + j;

            a1(100);//calling 1st lambda
            //delegate object will call the lambda function

            Console.WriteLine(a2(100, 200)); //calling 2nd lambda
            //Delegate object will call the lambda finction

            //Lambda: Expn tree (C# is parsed into tree data structure)
            Expression<Func<int, int, int>> a3 = (i, j) => i + j;

            Console.WriteLine("No of parameterss :", a3.Parameters.Count);
            Console.WriteLine("parameter #1 :", a3.Parameters[0]);
            Console.WriteLine("parameter #2 :", a3.Parameters[1]);
            Console.WriteLine("Body :", a3.NodeType);
            Console.WriteLine("Body :", a3.Body.NodeType);

            Console.WriteLine(a3.Compile()(300,500)); //Expression tree => MSIL

            //Expression.Variable(typeof(int), "a");
            //Expression.Variable(typeof(int), "b");
            //Expression.Assign();

            //By visiting this tree SQL queries can be generated
            //Which is done by and Object of a DbSet<> class
            //DbSet<>  inherits IQueriable<>
            //when C# compiled encounter  any object after "in" in the :LINQ
            //query that implements IQuerable it converts all the lambdas to
            //Expn tree
            //DbSet will convert expn tree at SQL
            //EF(entity framework) contains DbSet
        }
    }
}
