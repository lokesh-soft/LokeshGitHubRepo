﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App09
{
    class Program
    {
        static IEnumerable<int> Numbers()
        {
            System.Console.WriteLine("Numbers starts here");
            System.Console.WriteLine("Before 10");
            yield return 10;
            System.Console.WriteLine("After 10");

            System.Console.WriteLine("Before 20");
            yield return 10;
            System.Console.WriteLine("After 20");

            System.Console.WriteLine("Before 30");
            yield return 10;
            System.Console.WriteLine("After 30");

        }

        //
        //static IEnumerable <int> Numbers2()
        //{
        //    //yield
        //}

        static void Main(string[] args)
        {
            //Numbers();
            
            IEnumerable<int> en = Numbers();
            System.Console.WriteLine("Foreach starts here");
            
            foreach(int item in en)
            {
                System.Console.WriteLine("Inside foreach: " + item);
            }
        }
    }
}
