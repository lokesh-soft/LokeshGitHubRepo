﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

static class MyTask
{
    public static async Task<bool> DelayAsync(int time, CancellationToken token = default(CancellationToken))
    {
        System.Threading.Timer timer = null;
        TaskCompletionSource<bool> tcs = null;

        timer = new System.Threading.Timer(delegate
        {
            timer.Dispose();
            tcs.TrySetResult(true); // completed
        }, null, time, Timeout.Infinite);

        tcs = new TaskCompletionSource<bool>(timer);

        using (CancellationTokenRegistration ctr = token.Register(() => { timer.Dispose(); tcs.TrySetCanceled(); }))
        {
            return await tcs.Task;
        }
    }

    //public static Task DelayAsync(int time)
    //{
    //    TaskCompletionSource<int> tcs = null;
    //    System.Threading.Timer timer = null;

    //    timer = new System.Threading.Timer(delegate
    //    {
    //        timer.Dispose();
    //        tcs.TrySetResult(0);
    //    }, null, Timeout.Infinite, Timeout.Infinite);

    //    tcs = new TaskCompletionSource<int>(timer);

    //    timer.Change(time, Timeout.Infinite);

    //    return tcs.Task;
    //}


    //public static Task DelayAsync(int time, CancellationToken token = default(CancellationToken))
    //{
    //    TaskCompletionSource<int> tcs = new TaskCompletionSource<int>();


    //    System.Threading.Timer timer = new System.Threading.Timer(state =>
    //    {
    //        tcs.SetResult(0); // should be marked completed 
    //    }, null, time, 0);



    //    return tcs.Task; // incompleteTask;
    //}
}

class Program
{
    static void Main()
    {
        Form f = new Form();

        CancellationTokenSource cts = null;

        f.MouseDown += (sender, args) =>
        {
            if (args.Button == MouseButtons.Right)
            {
                cts.Cancel();
            }
        };

        f.MouseDown += async (sender, args) =>
        {
            if (args.Button == MouseButtons.Left)
            {
                cts = new CancellationTokenSource();

                Task incompleteTask = MyTask.DelayAsync(5000, cts.Token); // should not block the Main Thread

                System.GC.Collect(); // forcing the GC

                try
                {
                    await incompleteTask;
                    System.Console.WriteLine("Delay Over: Completed");

                }
                catch (TaskCanceledException ex)
                {
                    System.Console.WriteLine("Delay Over: Cancelled");
                }
            }
        };

        f.ShowDialog();
    }
}