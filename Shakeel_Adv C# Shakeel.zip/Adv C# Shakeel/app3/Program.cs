﻿//C# 2.0 yield- IEnumerable, generics: Classes, Methods, Interface and Delegates
//c# 3.0 : Extension Methods, Lambda, Action<> and Dunc<>

//LINQ -> Object and class that either implements IEnumerable<> or IQueryable<>


using System;
using System.Collections.Generic;
using System.Linq;

namespace app3
{
   static class  MyClassEx
    { 
        //Remains normal function it doesnt state machine class query excecutor.
        public static int Sum( this IEnumerable<int> Collection ) //No this in static
        {
            int s = 0;
            foreach (int item in Collection)
            {
                s += item;
            }
            return s;
        }

        public static IEnumerable<int> Where(this IEnumerable<int> collection,Func<int,bool> conditionCode )
        {
           // List<int> list=new List<int>();
            foreach (var item in collection)
            {
                if (conditionCode(item))
                {
                    yield return item;
                    //  list.Add(item);
                }
            }
          //  return list;
        }
    }
    class Program
    {
        static void Main()
        {
            int[] arr = {10, 20, 30,31,33,35, 40, 50,61}; // Array class implements IEnumerable
            List<int> list = new List<int>() {100, 200, 300, 400, 500};
                //List Object { , , } of initialization only possible when implements Ilist
            LinkedList<int> linkedList = new LinkedList<int>();
            linkedList.AddLast(1000);
            linkedList.AddLast(2000);
            linkedList.AddLast(3000);
            linkedList.AddLast(4000);
            linkedList.AddLast(5000);
            //int result = (from item in arr //Linq style of Quering
            //    where item > 30
            //    select item).Sum();
            int result = arr.Where(item => item > 30).Where(item => item % 2== 0).Sum(); // we get a feeling that where is a part of Array but there are still static methods ==>chaining
          //  int result1 = MyClassEx.Where(arr).Sum();//==> nesting
            System.Console.WriteLine(result);
            result = list.Where(item => item > 400).Sum();
            System.Console.WriteLine(result);
            result = linkedList.Where(item => item > 1000).Sum();
            System.Console.WriteLine(result);
            Console.Read();
        }
    }
}
