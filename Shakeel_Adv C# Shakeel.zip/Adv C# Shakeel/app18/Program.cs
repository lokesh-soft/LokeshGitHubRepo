﻿ using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

class Program
{
    static Task Fun1Async(CancellationToken token) // for Async Compute
    {
        // MT starts ST with the Help of Task that internally send request to ThreadPool
        // threadpool threads are background thread
        Task incompleteTask = Task.Run(() =>
        {
            // Async Compute
            for (int i = 1; i < 9999; i++) // ST
            {
                token.ThrowIfCancellationRequested();

                if (i == 5000)
                    throw new Exception("Some thing went wrong");

                System.Console.WriteLine("ST: " + i);
            }
        }, token);

        return incompleteTask;
    }


    static async Task<string> Fun2Async(CancellationToken token)  // for Async IO
    {
        HttpClient http = new HttpClient();

        Task<HttpResponseMessage> incompleteTask1 = http.GetAsync("http://www.amazon.in", token);

        await incompleteTask1; // the calling thread will be sent until the task is complete

        Task<string> incompleteTask2 = incompleteTask1.Result.Content.ReadAsStringAsync();

        await incompleteTask2; // the calling thread will be sent until the task is complete

        return incompleteTask2.Result; // wil give HTML
    }


    static void Main()
    {
        // 1. Create Window
        Form f = new Form();

        CancellationTokenSource cts = null;


        // 2. Add Event Handler
        f.MouseDown += (sender, args) =>
        {
            if (args.Button == MouseButtons.Right)
                cts.Cancel();
        };

        // 2. Add Event Handler
        f.MouseDown += async (sender, args) =>
        {
            if (args.Button == MouseButtons.Left)
            {
                cts = new CancellationTokenSource();

                Task incompleteTask = Fun1Async(cts.Token);
                //Task incompleteTask = Fun2Async(cts.Token);

                try
                {
                    await incompleteTask;
                    Console.WriteLine("Task Over: Completed");
                }
                catch (TaskCanceledException ex)
                {
                    Console.WriteLine("Task Over: Cancelled");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Task Over: Faulted");
                }

                // register a lmbda to know that task is over
                //incompleteTask.ContinueWith(ct =>
                //{
                //    if (ct.IsCanceled)
                //        Console.WriteLine("Task Over: Cancelled");
                //    else if (ct.IsFaulted)
                //        Console.WriteLine("Task Over: Faulted");
                //    else if (ct.IsCompleted)
                //        Console.WriteLine("Task Over: Completed");
                //}, TaskScheduler.FromCurrentSynchronizationContext());
            }
        };


        // 3. Start Message Loop
        Application.Run(f); // f.ShowDialog()


    } // MT returns to CLR without waiting for ST to complete its operation and CLR kills the app
}
