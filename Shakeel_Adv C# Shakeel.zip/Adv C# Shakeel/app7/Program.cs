﻿using System.Collections.Generic;
using System;
//using System.Linq;

class Program
{
    static int f1(int x) { return x * 2; }

    static void Main()
    {
        // Example - 1
        //Func<int, int> a1 = x => x * 2;
        //Func<int, int> a2 = new Func<int, int>(x => x * 2);
        //Func<int, int> a3 = new Func<int, int>(f1);

        //int result1 = a1(100); Console.WriteLine(result1);
        //int result2 = a2(100); Console.WriteLine(result2);
        //int result3 = a3(100); Console.WriteLine(result3);

        //return;

        // Example - 2
        // LINQ works on Collections - LINQ to Object
        //List<int> numbers = new List<int>() { 1, 2, 3, 4, 5, 2, 3, 4, 5, 3, 5, 3, 1, 2 };

        //// QP
        //IEnumerable<int> query1 = from number in numbers.Distinct()
        //                          select f1(number); // number * 2; // number => number * 2

        //// QE
        ////Console.WriteLine(query1.Sum());

        //// QE
        //foreach (var item in query1) 
        //{
        //    Console.WriteLine(item);
        //}

        //// QE
        //List<int> results = query1.ToList(); // get new collection

        //int result = new Func<int,int>( x => x * x ) (100);
        //Console.WriteLine(result);


        // Example - 2
        //Func<int, int> square = x => x * x; // delegate ( int x) { return x * x } ;
        //Func<int, int> cube = x => x * x * x; // delegate ( int x) { return x * x } ;

        //List<int> numbers = new List<int>() { 1, 2, 3, 4, 5, 2, 3, 4, 5, 3, 5, 3, 1, 2 };

        //// QP
        //var query2 = from number in numbers.Distinct()
        //             select new // CSC decides ClassName hence we cann write IEnumerable<ClassName>
        //             {
        //                 Square = square(number), // number * number,
        //                 Cube = cube(number) //number * number * number
        //             };
        ////QE
        //foreach (var item in query2)
        //{
        //    Console.WriteLine(item.Square + "\t" + item.Cube);
        //}

        // Example - 3
        //List<int> numbers = new List<int>() { 1, 2, 3, 4, 5, 2, 3, 4, 5, 3, 5, 3, 1, 2 };
        //// each number in the list occurs how many type

        //var query = from number in numbers
        //            group number by number into gr
        //            select new // CSC decides class name
        //            {
        //                Number = gr.Key,
        //                Occerrences = gr.Count()
        //            };

        //foreach (var item in query)
        //{
        //    Console.WriteLine(item.Number + "\t" + item.Occerrences);
        //}

        // Example - 4

        List<int> numbers = new List<int>() { 1, 2, 3, 4, 5, 2, 3, 4, 5, 3, 5, 3, 1, 2 };

        List<int> list = numbers.Distinct().ToList();

        //Dictionary<int, int> dict = numbers.Distinct().ToDictionary();

        foreach (var item in list)
        {
            Console.WriteLine(item);
        }
    }
}

static class aljskfjkjfkldjskfjdskfjksjfksdjkfjksdjfksdjkfjksdjfksd
{

    public static IEnumerable<int> Distinct(this IEnumerable<int> collection)
    {
        HashSet<int> numbers = new HashSet<int>();
        foreach (var item in collection)
        {
            if (numbers.Add(item)) // if it is unique it gets added and returns true
                yield return item;
        }
    }

    public static List<int> ToList(this IEnumerable<int> collection)
    {
        List<int> list = new List<int>();
        foreach (var item in collection)
        {
            list.Add(item);
        }
        return list;
    }

    //public static Dictionary<int, int> ToDictionary(this IEnumerable<int> collection)
    //{
    //    Dictionary<int, int> dict = new Dictionary<int, int>();
    //    foreach (var item in collection)
    //    {

    //    }
    //}
}


// items.Work1(); items.Work2().; items.Work3(); - OO

// items.Work1().Work2().Work3(); - FP
