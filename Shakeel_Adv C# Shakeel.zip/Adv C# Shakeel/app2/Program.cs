﻿

using System;
using System.Collections;
using System.Collections.Generic;

class Program
{
    //static IEnumerable<int> GetNumber()
    //{
    //    yield return 10;
    //    yield return 20;
    //    yield return 30;
    //}

    // CSC converts the GetNumbers to the following
    class GetNumber_0 : IEnumerable<int>
    {
        class GetNumber_Enumerator : IEnumerator<int>
        {
            public int Current
            {
                get
                {
                    return data;
                }
            }

            object IEnumerator.Current // NON GENERIC
            {
                get
                {
                    throw new NotImplementedException();
                }
            }

            public void Dispose() // foreach calls Dispose
            {
                // What will it dispose ?
            }

            int data;
            int state = 1;

            public bool MoveNext()
            {
                if (state == 1)
                {
                    data = 10; // yield return 10;
                    state = 2;
                    return true;
                }
                else if (state == 2)
                {
                    data = 20; // yield return 20;
                    state = 3;
                    return true;
                }
                else if (state == 3)
                {
                    data = 30; // yield return 30;
                    state = 4;
                    return true;
                }
                else
                    return false;
            }

            public void Reset() // foreach doesn't call Reset
            {
                throw new NotImplementedException();
            }
        }

        public IEnumerator<int> GetEnumerator()
        {
            return new GetNumber_Enumerator();
        }

        IEnumerator IEnumerable.GetEnumerator() // NON-GENERIC for backward with .NET 1.0 and 1.1
        {
            throw new NotImplementedException();
        }
    }

    static IEnumerable<int> GetNumber()
    {
        return new GetNumber_0();
    }


    static void Main()
    {
        // version 1
        //IEnumerable<int> en = GetNumber();
        //IEnumerator<int> et = en.GetEnumerator();
        //et.MoveNext();
        //Console.WriteLine(et.Current); // 10
        //et.MoveNext();
        //Console.WriteLine(et.Current); // 20
        //et.MoveNext();
        //Console.WriteLine(et.Current); // 30

        // version 2
        //foreach ( int number in GetNumber())
        //    Console.WriteLine(number);

        // version 3
        IEnumerable<int> en = GetNumber();
        IEnumerator<int> et = en.GetEnumerator();
        while (et.MoveNext())
            Console.WriteLine(et.Current); // 10 20 30
        Console.ReadKey();
    }
}
