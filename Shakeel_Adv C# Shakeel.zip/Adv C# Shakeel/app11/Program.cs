﻿ 
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Threading;

class Program
{
    static Task<int> Fun1Async()
    {
        return Task<int>.Run(async () =>
        {
            int count = 1;
            for (int i = 0; i < 5; i++)
            {
                //Thread.Sleep(1000); // blocks the thread

                await Task.Delay(1000); // sends the thread back to pool

                //Thread.SpinWait(999999999); // consumes CPU
                count++;
            }
            return count;
        });
    }

    static Task<int> Fun2Async()
    {
        // TP is the Caller of the Lambda
        return Task<int>.Run(async () =>
        {
            int count = 1;
            for (int i = 0; i < 5; i++)
            {
                //Thread.Sleep(1000); // blocks the thread

                await Task.Delay(1000); // sends the thread back to pool

                //Thread.SpinWait(999999999); // consumes CPU
                count++;
            }
            return count;
        });
    }

    static void Main()
    {
        Form f = new Form();

        // ML is the Caller of the Event Handler
        f.MouseDown += async (sender, args) =>
        {
            //Thread.Sleep(5000);
            await Task.Delay(5000);
            MessageBox.Show("LR operation done");

            //Task<int> t = Fun1Async();

            ////t.Wait(); // blocking the main thread

            //int result = await t; // sends MT to ML

            //MessageBox.Show(result.ToString()); 
        };

        f.ShowDialog();

        //Example - 3
        //Task<int> t = Fun1Async();
        //t.Wait(); // blocks the main thread 
        //System.Console.WriteLine(t.Result); // main thread

        // Example - 2
        //Task<int> t = Task<int>.Run(() =>
        //                        {
        //                            return (10 + 20);
        //                        });

        //t.Wait(); // blocks the main thread 
        //System.Console.WriteLine(t.Result); // main thread

        // Example - 1
        //Task t = Task.Run(() =>
        //            {
        //                System.Console.WriteLine(10 + 20);
        //            });

        //t.Wait(); // blocks the main thread 
    }
}
