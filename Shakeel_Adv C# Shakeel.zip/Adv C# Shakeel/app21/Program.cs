﻿using System.Collections.Generic;
using System.Threading;
using System.Reactive.Linq;
using System;
using System.Reactive.Concurrency;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using System.Windows.Input;

// Synchronous and Pull-based way of obtaining the data
class Program
{
    // function acts like collection of data
    static IEnumerable<string> GetMessages()  // MT
    {
        Thread.Sleep(2000); // MT
        yield return "1 - Message"; // MT

        Thread.Sleep(2000); // MT
        yield return "2 - Message"; // MT

        Thread.Sleep(2000); // MT
        yield return "3 - Message"; // MT
    }

    [STAThread]
    static void Main()
    {
        // 1
        //// PULLING the data
        //IEnumerable<string> sm = GetMessages(); // MT
        //foreach (string item in sm) // MT
        //{
        //    System.Console.WriteLine(item); // MT
        //}
        //Console.WriteLine("End of Main");


        // 3
        // LINQ
        //IEnumerable<string> sm = (from message in GetMessages()
        //                          select message).Skip(1).Take(2);
        //foreach (string item in sm) // MT
        //{
        //    System.Console.WriteLine(item); // MT
        //}
        //Console.WriteLine("End of Main");



        // 2
        // PUSHING the data
        // ToObservable() returns an observable object. this object
        // is capable of pushing the data in either asynchronous or synchronous
        //IObservable<string> o = GetMessages().ToObservable(TaskPoolScheduler.Default); // MT
        ////ask observable object to start pushing the data
        //o.Subscribe(message => // MT
        //{
        //    Console.WriteLine(message); // MT
        //});
        //Console.WriteLine("End of Main");
        //Console.ReadLine();



        // 4
        //IObservable<string> o = GetMessages().ToObservable(TaskPoolScheduler.Default).Skip(1).Take(2); // MT
        ////ask observable object to start pushing the data
        //o.Subscribe(message => // MT
        //{
        //    Console.WriteLine(message); // MT
        //});
        //Console.WriteLine("End of Main");
        //Console.ReadLine();



        // 5
        // LINQ
        //IEnumerable<string> sm = (from message in GetMessages()
        //                          select message).Skip(1).Take(2).Where(message => message.Contains("2"));
        //foreach (string item in sm) // MT
        //{
        //    System.Console.WriteLine(item); // MT
        //}
        //Console.WriteLine("End of Main");


        // 6
        //IObservable<string> o = GetMessages().ToObservable(TaskPoolScheduler.Default).Skip(1).Take(2).Where(message => message.Contains("2")); // MT
        ////ask observable object to start pushing the data
        //o.Subscribe(message => // MT
        //{
        //    Console.WriteLine(message); // MT
        //});
        //Console.WriteLine("End of Main");
        //Console.ReadLine();


        // 7
        //var ob = Observable.Create<string>(observer =>
        //                                   {
        //                                       var timer = new System.Timers.Timer();
        //                                       timer.Interval = 1000;
        //                                       timer.Elapsed += (s, e) => observer.OnNext("tick");
        //                                       timer.Start();
        //                                       return timer;
        //                                   });


        //var subscription = ob.Subscribe(Console.WriteLine);


        //Console.ReadLine();
        //subscription.Dispose();

        //// 8
        //IObservable<char> inputob = Observable.Create<char>(observer =>
        //                                                            {
        //                                                                while (true)
        //                                                                {
        //                                                                    char input = Console.ReadKey(true).KeyChar;
        //                                                                    observer.OnNext(input);
        //                                                                }
        //                                                                return () => { };
        //                                                            });
        //inputob
        //    .Where(n => !"aeiou".Contains(n))
        //    .Skip(3)
        //    .Take(3)
        //    .Select(n => Char.ToUpper(n))
        //    .Subscribe(n => Console.WriteLine("I am subscriver: " + n));

        //IObservable<string> o = GetMessages().ToObservable(); // MT
        //o
        //    .Where(n => n.Contains("e")==false)
        //    .Subscribe(message => Console.WriteLine(message));
        //Console.WriteLine("End of Main");
        //Console.ReadLine();



        Window w = new Window();
        Canvas cnv = new Canvas() { Background = System.Windows.Media.Brushes.Cyan };
        w.Content = cnv;
        w.AllowDrop = true;
        w.Drop += (sender, e) =>
        {
            string[] files = (string[])e.Data.GetData(System.Windows.DataFormats.FileDrop);

            BitmapImage bi = new BitmapImage();
            bi.BeginInit();
            bi.UriSource = new Uri(files[0], UriKind.Relative);
            bi.DecodePixelHeight = bi.DecodePixelWidth = 100;
            bi.EndInit();

            System.Windows.Controls.Image img = new System.Windows.Controls.Image();
            img.SetValue(Canvas.LeftProperty, 10.0);
            img.SetValue(Canvas.TopProperty, 10.0);
            img.Width = img.Height = 100;
            img.Source = bi;

            cnv.Children.Add(img);


            // ---------------------------------------------------------------
            var mouseMoveObs = Observable.FromEventPattern<MouseEventArgs>(img, "MouseMove");
            var mouseDownObs = Observable.FromEventPattern<MouseEventArgs>(img, "MouseDown");
            var mouseUpObs = Observable.FromEventPattern<MouseEventArgs>(img, "MouseUp");


            var o = mouseMoveObs
                       .SkipUntil(mouseDownObs)
                       .TakeUntil(mouseUpObs)
                       .Select(a => a.EventArgs.GetPosition(cnv))
                       .Let(pt => pt.Zip(pt.Skip(1), (prev, cur) => new { X = cur.X - prev.X, Y = cur.Y - prev.Y }))
                       .Repeat();

            Console.WriteLine(Thread.CurrentThread.ManagedThreadId);

            var subscription = o
                                .ObserveOnDispatcher()
                                .Subscribe(value =>
                                {
                                    Console.WriteLine(Thread.CurrentThread.ManagedThreadId);
                                    Canvas.SetLeft(img, Canvas.GetLeft(img) + value.X);
                                    Canvas.SetTop(img, Canvas.GetTop(img) + value.Y);
                                });

        };
        w.ShowDialog();

    }
}

public static class EnumerableExx
{
    public static U Let<T, U>(this T source, Func<T, U> f)
    {
        return f(source);
    }
} 