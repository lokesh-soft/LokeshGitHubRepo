﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;

class Disk
{
    private int count; // instance of field of Disk object


    // observer pattern - event
    public event Action<string> FolderEntered;
    // 1. event - only the code of this class can raise the event
    // 2. event - add_FolderEntered and remove_Entered with sychronization-safe code
    // 3. event - extra information in metadata
    // 4. event - can also be part of interface

    // helps Task object (for the Task object)
    private CancellationTokenSource cts = null;

    public int Count
    {
        get
        {
            return count;
        }
    }

    private Task t;

    public Task StartTraverseAsync(string startingFolder)
    {
        count = 0;

        if (t != null)
        {
            if (t.Status == TaskStatus.Running)
            {
                cts.Cancel();
            }
        }

        cts = new CancellationTokenSource(); // create new object for every new traversal

        // Task.Run requests the threadpool part of our process to give a thread
        t = Task.Run(() =>
        {


            Stopwatch sw = Stopwatch.StartNew();
            Traverse(startingFolder); // ST
            MessageBox.Show(sw.ElapsedMilliseconds.ToString());

            t = null;

        }, cts.Token);

        return t;

    } // MT will return with 50 ms


    public void StopTraverse()
    {
        cts.Cancel(); // only the request NOT to the Thread instead it is just request CTS object
    }

    // traverse all the sub folders and count numbers of files in them
    private void Traverse(string folder) // LR Compute-bound
    {
        //if (cts.IsCancellationRequested) return ; // OR
        cts.Token.ThrowIfCancellationRequested();

        //Thread.CurrentThread.Abort(); // very dangerous for threadpool threads
        try
        {
            string[] files = Directory.GetFiles(folder, "*.*");

            //count += files.Length; // sync issue
            Interlocked.Add(ref count, files.Length);

            // ****** TODO: open in dotpeek view what it is expanded
            FolderEntered?.Invoke(folder); // raising the event

            string[] subFolders = Directory.GetDirectories(folder);
            //foreach (string subFolder in subFolders)
            //{
            //    Traverse(subFolder);
            //}

            Parallel.ForEach(subFolders, subFolder =>
            {
                Traverse(subFolder);
            });
        }
        catch (Exception ex) // *** Never Leave the Catch Empty ***
        {
            // Log the Exception
        }
    }
}

class MyForm : Form
{
    Button start = new Button();
    Button stop = new Button();
    Label folderDisplay = new Label();

    public MyForm()
    {
        start.Text = "Start";
        start.Location = new Point(10, 10);
        this.Controls.Add(start);

        stop.Text = "Stop";
        stop.Location = new Point(100, 10);
        this.Controls.Add(stop);

        folderDisplay.Location = new Point(10, 50);
        folderDisplay.Size = new Size(600, 30);
        this.Controls.Add(folderDisplay);

        start.Click += Start_Click;
        stop.Click += Stop_Click;

        disk.FolderEntered += Disk_FolderEntered;
    }


    private void Disk_FolderEntered(string folder) // ST
    {
        // sends the message to main thread to call lambda to update ui
        folderDisplay.Invoke(new Action(() =>
        {
            folderDisplay.Text = folder; // ST
        }));
    }

    private void Stop_Click(object sender, EventArgs e)
    {
        disk.StopTraverse();

        MessageBox.Show("Cancelled: " + disk.Count.ToString());
    }

    Disk disk = new Disk(); // field of Form

    private async void Start_Click(object sender, EventArgs e) // MT
    {
        Task t = disk.StartTraverseAsync(@"c:\"); // MT calls this function 
        // but comes back immediately without completing the traverse

        await t;  // sends MT back to the message loop

        MessageBox.Show("Completed: " + disk.Count.ToString());
    }
}

class Program
{
    static void Main()
    {
        // Create GUI to start the traversal and display each folder being traversed
        MyForm f = new MyForm();
        f.ShowDialog();
    }
}