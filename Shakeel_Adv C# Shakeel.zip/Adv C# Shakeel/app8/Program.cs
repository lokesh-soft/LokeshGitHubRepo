﻿using System;
using System.Linq.Expressions;

class Program
{
    static void Main()
    {
        Action<int, int> a1 = (x, y) => Console.WriteLine(x + y); // Function (there can be multiple lines)
        a1(10, 20); // call the function

        Console.WriteLine("-----------------");

        Expression<Action<int, int>> a3 = (x, y) => Console.WriteLine(x + y); // Tree Data Structure with Code in it
        Console.WriteLine("Number of Parameters: " + a3.Parameters.Count);
        Console.WriteLine("All Parameters: " + a3.Parameters[0] + " " + a3.Parameters[1]);
        Console.WriteLine("Body of Code: " + a3.Body);

        Console.WriteLine("-----------------");

        Func<int, int, int> a2 = (x, y) => x + y; // Function (there can be multiple lines)
        Console.WriteLine(a2(100, 200)); // calling the function and obtaining result

        Console.WriteLine("-----------------");

        Expression<Func<int, int, int>> a4 = (x, y) => x + y; // Tree Data Structure with Code in it
        Console.WriteLine("Number of Parameters: " + a4.Parameters.Count);
        Console.WriteLine("All Parameters: " + a4.Parameters[0] + " " + a4.Parameters[1]);
        Console.WriteLine("Body of Code: " + a4.Body);
        Console.WriteLine("Type of Code in Body: " + a4.Body.NodeType);

        Console.WriteLine("-----------------");


    }
}