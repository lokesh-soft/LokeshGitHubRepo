﻿using System.Collections.Generic;
using System;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices;

// Print the distict value
class Program
{
    static void Main()
    {
        List<List<int>> l = new List<List<int>>()
        {
            new List<int>( ) { 11, 12, 3, 4 },
            new List<int>( ) { 11, 12, 13, 14 },
            new List<int>( ) { 6, 7, 8, 9 },
            new List<int>( ) { 15, 5, 8, 10 },
        };
        var query = from n in l.SelectMany(x => x ).Distinct().Where(x=>x % 2==0)
            orderby n ascending
            select n;
        foreach (var item in query)
        {
            Console.WriteLine(item.ToString());
        }

    }
}
