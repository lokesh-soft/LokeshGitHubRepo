﻿using System;
using System.Reflection;

using System.Collections.Generic;

public interface IMessenger
{
    void SendMessage(string message);
}

