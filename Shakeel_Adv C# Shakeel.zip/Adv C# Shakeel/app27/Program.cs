﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        int[] items = new int[100000000];
        for (int i = 1; i < items.Length; i++)
        {
            items[i - 1] = i;
        }

        Console.WriteLine(Environment.ProcessorCount); // Dual Core (2) => 4 HyperThreaded processors 
                                                       // Each Core is supports HyperThreading = 2

        var query = (from item in items.AsParallel().WithDegreeOfParallelism(Environment.ProcessorCount).WithMergeOptions(ParallelMergeOptions.Default)
                     where item % 2 == 0
                     select item);

        Stopwatch sw = Stopwatch.StartNew();
        query.ForAll((item) =>
        {
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
            item = item * item;
        }); // executor
        Console.WriteLine(sw.ElapsedMilliseconds);


        //Stopwatch sw = Stopwatch.StartNew();
        //Parallel.For(1, items.Length + 1, new ParallelOptions() { MaxDegreeOfParallelism = Environment.ProcessorCount }, 
        //    (item) =>
        //            {
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //                item = item * item;
        //            });
        //Console.WriteLine(sw.ElapsedMilliseconds);

        //Stopwatch sw = Stopwatch.StartNew();
        //int x = items.Length / 4 ; 
        //int y = items.Length / 2; 
        //int z = y + items.Length / 4; 
        //Task t1 = Task.Run(() =>
        //{
        //    for (int i = 1; i < x; i++)
        //    {
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //    }
        //});

        //Task t2 = Task.Run(() =>
        //{
        //    for (int i = x; i < y; i++)
        //    {
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //    }
        //});

        //Task t3 = Task.Run(() =>
        //{
        //    for (int i = y; i < z; i++)
        //    {
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //    }
        //});

        //Task t4 = Task.Run(() =>
        //{
        //    for (int i = z; i < items.Length; i++)
        //    {
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //        items[i - 1] = items[i - 1] * items[i - 1];
        //    }
        //});


        //Task.WaitAll(t1, t2, t3, t4);
        //Console.WriteLine(sw.ElapsedMilliseconds);



        //Stopwatch sw = Stopwatch.StartNew();
        //for (int i = 1; i < items.Length; i++) 
        //{
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //    items[i - 1] = items[i - 1] * items[i - 1];
        //}
        //Console.WriteLine(sw.ElapsedMilliseconds);
    }
}