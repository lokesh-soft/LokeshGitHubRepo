﻿using System;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        CancellationTokenSource cts = new CancellationTokenSource();

        // MT starts ST with the Help of Task that internally send request to ThreadPool
        // threadpool threads are background thread
        Task t = Task.Run(() =>
        {
            // Async Compute
            for (int i = 1; i < 9999; i++) // ST
            {
                cts.Token.ThrowIfCancellationRequested();

                if (i == 5000)
                    throw new Exception("Some thing went wrong");

                System.Console.WriteLine("ST: " + i);
            }
        }, cts.Token);

        // register a lmbda to know that task is over
        t.ContinueWith(ct =>
        {
            if (ct.IsCanceled)
                Console.WriteLine("Task Over: Cancelled");
            else if (ct.IsFaulted)
                Console.WriteLine("Task Over: Faulted");
            else if (ct.IsCompleted)
                Console.WriteLine("Task Over: Completed");
        });




        while (true) // MT
        {
            string input = Console.ReadLine(); // in GUI instead of this Message Loop runs
            if (input == "stop")
            {
                cts.Cancel();
            }
        }
    } // MT returns to CLR without waiting for ST to complete its operation and CLR kills the app
}
