﻿ 
using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

static class Sample
{
    public static void RunsForever() // ST
    {
        for (int i = 0; i < 9999; i++) // ST
            Console.WriteLine(i); // ST
    }
}

static class MyTask
{
    public static async Task<int> DelayAsync(int time, CancellationToken token = default(CancellationToken))
    {
        System.Threading.Timer timer = null;
        TaskCompletionSource<int> tcs = null;

        // timer doesn't start here
        timer = new System.Threading.Timer(state =>
        {
            timer.Dispose();
            tcs.TrySetResult(0); // completed
        }, null, Timeout.Infinite, Timeout.Infinite);

        tcs = new TaskCompletionSource<int>(timer);

        using (CancellationTokenRegistration ctr = token.Register(() => { timer.Dispose(); tcs.TrySetCanceled(); }))
        {
            // timer starts here
            timer.Change(time, Timeout.Infinite);
            return await tcs.Task; // incomplete task object
        }
    }

    public static async Task<int> RunsForeverAsync(CancellationToken token = default(CancellationToken))
    {
        Thread st = null;
        TaskCompletionSource<int> tcs = null;

        // thread doesnt start here
        st = new Thread(() =>
        {
            Sample.RunsForever(); // ST
            tcs.TrySetResult(0); // completed
        });

        tcs = new TaskCompletionSource<int>(st);

        using (CancellationTokenRegistration ctr = token.Register(() => { st.Abort(); tcs.TrySetCanceled(); }))
        {
            // thread starts here
            st.Start();
            return await tcs.Task; // incomplete task object
        }
    }
}

class Program
{
    static void Main()
    {
        Form f = new Form();

        CancellationTokenSource cts = null;

        f.MouseDown += (sender, args) =>
        {
            if (args.Button == MouseButtons.Right)
            {
                cts.Cancel();
            }
        };

        f.MouseDown += async (sender, args) =>
        {
            if (args.Button == MouseButtons.Left)
            {
                cts = new CancellationTokenSource();

                //Task incompleteTask = MyTask.DelayAsync(5000,cts.Token); // should not block the Main Thread
                Task incompleteTask = MyTask.RunsForeverAsync(cts.Token); // should not block the Main Thread

                System.GC.Collect(); // forcing the GC

                try
                {
                    await incompleteTask;
                    System.Console.WriteLine("Delay Over: Completed");
                }
                catch (TaskCanceledException ex)
                {
                    System.Console.WriteLine("Delay Over: Cancelled");
                }
            }
        };

        f.ShowDialog();
    }
}
