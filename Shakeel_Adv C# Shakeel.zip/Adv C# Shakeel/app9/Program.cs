﻿using System;
using System.Reflection;
using System.ComponentModel.Composition; // MEF
using System.ComponentModel.Composition.Hosting; // MEF
using System.Collections.Generic;

//interface IMessenger
//{
//    void SendMessage(string message);
//}

class Program
{
    [ImportMany] // DI
    public List<IMessenger> Messengers { get; set; } // non-static

    static void Main()
    {
        // Create an object of Email class without using the name of the Class
        // Ans: Reflection
        //Assembly asm = Assembly.GetExecutingAssembly(); // Current EXE
        //Type[] types = asm.GetTypes();
        //foreach (var type in types)
        //{
        //    Console.WriteLine(type);

        //    if ( type.GetInterface("IMessenger") != null)
        //    {
        //        object o = Activator.CreateInstance(type);
        //        (o as IMessenger).SendMessage("Hello");
        //    }
        //}

        // search the classes in the Current EXE
        AssemblyCatalog ac = new AssemblyCatalog(Assembly.GetExecutingAssembly());

        // search the classes in the DLL of the Currect EXE Folder
        DirectoryCatalog dc = new DirectoryCatalog(Environment.CurrentDirectory);
        // any number of directory catalogs

        AggregateCatalog ag = new AggregateCatalog();
        ag.Catalogs.Add(ac);
        ag.Catalogs.Add(dc);

        CompositionContainer cc = new CompositionContainer(ag);

        Program p = new Program();
        cc.ComposeParts(p); // get all the classes and create their objects

        foreach (IMessenger messenger in p.Messengers)
        {
            messenger.SendMessage("Hello");
        }

        Console.ReadLine();
    }
}

[Export(typeof(IMessenger))]
class Email : IMessenger
{
    public void SendMessage(string message)
    {
        Console.WriteLine("\t" + message + " sent by Email");
    }
}

//[Export(typeof(IMessenger))]
class SMS : IMessenger
{
    public void SendMessage(string message)
    {
        Console.WriteLine("\t" + message + " sent by SMS");
    }
}
