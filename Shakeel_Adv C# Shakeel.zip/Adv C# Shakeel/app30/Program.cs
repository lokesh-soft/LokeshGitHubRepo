﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

 
    class Program
    {
        static void Main()
        {

            int[] a = {1, 2, 3, 4, 5};
            List<int> b = new List<int>(){ 1, 2, 3, 4, 5 };

            Console.WriteLine(a.SequenceEqual(b));
    }
    }
