﻿using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

class Program
{
    static Task<int> Fun1Async()
    {
        return Task<int>.Run(() => { Thread.SpinWait(999999999); return 10; });
    }

    static void Main()
    {
        Thread.CurrentThread.Name = "MT";


        Form f = new Form();

        f.MouseDown += (sender, args) =>
        {
            Task<int> task = Fun1Async();

            task.ContinueWith(ct =>
            {
                System.Console.WriteLine(Thread.CurrentThread.Name);
                System.Console.WriteLine(ct.Result); // blocks main thread if task is running
            }, TaskScheduler.FromCurrentSynchronizationContext()); //avoid invoke to update the UI

            //await task; // MT returns to message loop

            //System.Console.WriteLine(task.Result); // blocks main thread if task is running

        }; // MT returns to message loop

        f.ShowDialog();

        //Task<int> task  = Fun1Async();
        //System.Console.WriteLine(task.Result); // Result blocks calling thread
    }
}
