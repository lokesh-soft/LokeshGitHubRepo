﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace compileex
{
    class Program
    {
        static void Main(string[] args)
        {
            var solution = new Task(() =>
            {
                var tf = new TaskFactory(TaskCreationOptions.AttachedToParent, TaskContinuationOptions.AttachedToParent);
                var D = tf.StartNew(() => Compile("D"));
                var E = tf.StartNew(() => Compile("E"));
                var F = tf.StartNew(() => Compile("F"));

                var B = D.ContinueWith(task => Compile("B"));
                var C = tf.ContinueWhenAll(new Task[] { E, F }, tasks => Compile("C"));
                var A = tf.ContinueWhenAll(new Task[] { B, C }, tasks => Compile("A"));
            });
            solution.Start();
        }
    }
}
