﻿
using System;
using System.Collections.Generic;
using System.Linq;

class User
{
    public int UserId { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
}

class Role
{
    public int RoleId { get; set; }
    public string Rolename { get; set; }
}

class UserInRole
{
    public int UserId { get; set; }
    public int RoleId { get; set; }
}

class Program
{
    static void Main()
    {
        var users = new List<User>()
        {
            new User() { UserId=1, Username="A1", Password="aaa" },
            new User() { UserId=2, Username="A2", Password="aaa" },
            new User() { UserId=3, Username="A3", Password="aaa" },
            new User() { UserId=4, Username="A4", Password="aaa" },
            new User() { UserId=5, Username="A5", Password="aaa" },
            new User() { UserId=6, Username="A6", Password="aaa" },
        };

        var roles = new List<Role>()
        {
            new Role() { RoleId=1, Rolename="admin" },
            new Role() { RoleId=2, Rolename="seller" },
            new Role() { RoleId=3, Rolename="buyer" },
        };

        var usersinroles = new List<UserInRole>()
        {
            new UserInRole() { UserId=1, RoleId=1 },
            new UserInRole() { UserId=2, RoleId=1 },
            new UserInRole() { UserId=1, RoleId=2 },
            new UserInRole() { UserId=3, RoleId=3 },
            new UserInRole() { UserId=4, RoleId=3 },
            new UserInRole() { UserId=5, RoleId=2 },
            new UserInRole() { UserId=5, RoleId=3 },
            new UserInRole() { UserId=6, RoleId=1 },
        };

        var query3 = (from user in users
            join ui in usersinroles on user.UserId equals ui.UserId
            join role in roles on ui.RoleId equals role.RoleId
            group role.Rolename by user.Username);

        
     









        //Each user has what roles //after "in" is " data store" from and let introduces new variable in query
        //All linq query should end with select or group
        //after by is the key before by is the value

        //Query Preparation
        //Query1 refers to state machine object
        IEnumerable<IGrouping<string, string>> query1 = (from user in users
                                                         join ui in usersinroles on user.UserId equals ui.UserId
                                                         join role in roles on ui.RoleId equals role.RoleId
                                                         group role.Rolename by user.Username);

        // Each role has which user

        IEnumerable<IGrouping<string, string>> query2 = from user in users
                                                        join ui in usersinroles on user.UserId equals ui.UserId
                                                        join role in roles on ui.RoleId equals role.RoleId
                                                        group user.Username by role.Rolename;


        //Query execution function in Linq
        //Count(), Sum(), Average(), First(), FirstorDefault(), Single(), SingleDefault()
        //ToList(), To Array

        foreach (var group in query2) //Get Enumerator and Movenext repeatedly 
        {
            Console.WriteLine(group.Key);
            foreach (var rolename in group)
            {
                Console.WriteLine(rolename);
            }

        }
        Console.ReadLine();
    }
}
