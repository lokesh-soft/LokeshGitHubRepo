﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] arr = {10, 11, 12, 13, 12, 11, 10};
        //IEnumerable<int> data = (from item in arr
        //    where item % 2 == 0
        //    select item).Distinct();
        IEnumerable<int> data = arr.Distinct().Where(item => item % 2 == 0);
        
        
        //Query Executor
        foreach (var item in data)
        {
            System.Console.WriteLine(item);
        }
      

        int sum = data.Sum(); 
        Console.WriteLine("Sum :"+sum);

        int count = data.Count();
        Console.WriteLine("Count :"+count);
        Console.ReadLine();

    }
    
}