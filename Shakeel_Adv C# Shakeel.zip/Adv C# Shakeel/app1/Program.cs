﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;
using System.Net;
using System.Threading.Tasks;

class MyForm : Form
{
    Button b = new Button(); // MT

    TextBox t1 = new TextBox(); // MT
    TextBox t2 = new TextBox(); // MT
    TextBox t3 = new TextBox(); // MT

    public MyForm(/* this = ref. of calling object */) // MT
    {
        this.b.Text = "Get HTML"; // MT
        this.b.Location = new Point(50, 10); // MT
        this.Controls.Add(this.b); // MT

        this.t1.Location = new Point(50, 50); // MT
        this.t1.Size = new Size(200, 600); // MT
        this.t1.Multiline = true;  // MT
        this.Controls.Add(this.t1);  // MT

        this.t2.Location = new Point(250, 50); // MT
        this.t2.Size = new Size(200, 600); // MT
        this.t2.Multiline = true;  // MT
        this.Controls.Add(this.t2);  // MT

        this.t3.Location = new Point(450, 50); // MT
        this.t3.Size = new Size(200, 600); // MT
        this.t3.Multiline = true;  // MT
        this.Controls.Add(this.t3);  // MT

        this.AutoSize = true;  // MT

        this.b.Click += B_Click;
    }

    // this event handler will called by the MT
    private async void B_Click(object sender, EventArgs e) // MT
    {
        WebClient http1 = new WebClient(); // MT
        WebClient http2 = new WebClient(); // MT
        WebClient http3 = new WebClient(); // MT

        this.b.Text = "Loading...";
        //this.b.Enabled = false;

        // Async IO Requests
        //Task<string> htmlTask1 = http.DownloadStringTaskAsync("http://www.amazon.in"); // MT gets blocked until HTML is available
        //// Sends the Main Thread back to Caller/Message Loop in such a way that 
        //// it should come back Task object status is complete
        //await htmlTask1;

        //Task<string> htmlTask2 = http.DownloadStringTaskAsync("http://www.flipkart.com");
        //// Sends the Main Thread back to Caller/Message Loop in such a way that 
        //// it should come back Task object status is complete
        //await htmlTask2;


        //Task<string> htmlTask3 = http.DownloadStringTaskAsync("http://www.leadows.com");
        //// Sends the Main Thread back to Caller/Message Loop in such a way that 
        //// it should come back Task object status is complete
        //await htmlTask3;

        // Async + Parallel IO Requests
        Task<string> htmlTask1 = http1.DownloadStringTaskAsync("http://www.amazon.in"); // MT gets blocked until HTML is available
        Task<string> htmlTask2 = http2.DownloadStringTaskAsync("http://www.flipkart.com"); // MT gets blocked until HTML is available
        Task<string> htmlTask3 = http3.DownloadStringTaskAsync("http://www.leadows.com"); // MT gets blocked until HTML is available

        // Sends the Main Thread back to Caller/Message Loop in such a way that 
        // it should come back Task object status is complete
        //await Task.WhenAny(htmlTask1, htmlTask2, htmlTask3);
        List<Task<string>> tasks=new List<Task<string>>() {htmlTask1,htmlTask2,htmlTask3};
        while (tasks.Count!=0)
        {
            Task<string> completed = await Task.WhenAny(tasks);
            if (completed==htmlTask1)
            {
                this.t1.Text = completed.Result;

            }
            if (completed == htmlTask2)
            {
                this.t2.Text = completed.Result;

            }
            if (completed == htmlTask3)
            {
                this.t3.Text = completed.Result;

            }
            tasks.Remove(completed);
        }

        this.b.Text = "Get HTML";

     
    }
}

class Program : System.Object
{
    // CLR uses Main Thread to call Main()
    static void Main() // MT
    {
        MyForm f = new MyForm(); // MT

        f.ShowDialog(); // Starts the Message Loop using MT
        // This Message Loop is capable of picking messages from MT's Message Queue
    }
}
