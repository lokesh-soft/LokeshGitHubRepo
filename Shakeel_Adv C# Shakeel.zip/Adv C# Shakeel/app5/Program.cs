﻿
using System.Collections.Generic;
using System;
using System.Linq;

class Option
{
    public string OptionText { get; set; }
    public bool IsCorrect { get; set; }
    public int Marks { get; set; }

    public bool IsSelectedByUser { get; set; }
}

class Question
{
    public string Statement { get; set; }
    public List<Option> Options { get; set; }
}

class Program
{
    static void Main()
    {
        List<Question> questions = new List<Question>()
        {
            new Question()
            {
                Statement = "AAA",
                Options = new List<Option>()
                {
                    new Option() { OptionText="A1", IsCorrect=true, Marks=1, IsSelectedByUser = true },
                    new Option() { OptionText="A2", IsCorrect=true, Marks=5, IsSelectedByUser = false },
                    new Option() { OptionText="A3", IsCorrect=false, Marks=5, IsSelectedByUser = true },
                }
            },
            new Question()
            {
                Statement = "BBB",
                Options = new List<Option>()
                {
                    new Option() { OptionText="B1", IsCorrect=false, Marks=1, IsSelectedByUser = false },
                    new Option() { OptionText="B2", IsCorrect=false, Marks=5, IsSelectedByUser= false },
                }
            },
        };

        int testTotalMarks = (from question in questions
                              from option in question.Options
                              where option.IsCorrect
                              select option.Marks).Sum();

        //int correctMarks = (from question in questions
        //                    from option in question.Options
        //                    where (option.IsCorrect == true && option.IsSelectedByUser == true)
        //                    select option.Marks).Sum();

        //int wrongMarks = (from question in questions
        //                  from option in question.Options
        //                  where (option.IsCorrect == false && option.IsSelectedByUser == true)
        //                  select option.Marks).Sum();
        //Console.WriteLine(correctMarks - wrongMarks + "  out of  " + testTotalMarks);

        var UserMarks = (from question in questions
                         from option in question.Options
                         let usermarks = (option.IsCorrect == true && option.IsSelectedByUser == true) ? option.Marks : (option.IsCorrect == false && option.IsSelectedByUser == true) ? option.Marks * -1 : 0
                         select usermarks).Sum();

        Console.WriteLine(UserMarks + "  out of  " + testTotalMarks);
    }
}
