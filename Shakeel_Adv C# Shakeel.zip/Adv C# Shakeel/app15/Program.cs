﻿using System;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static Task Fun1Async(CancellationToken token)
    {
        Task t = Task.Run(() =>
        {
            // Async Compute
            for (int i = 1; i < 4000; i++) // ST
            {
                token.ThrowIfCancellationRequested();

                if (i == 3000)
                    throw new Exception("Some thing went wrong");

                System.Console.WriteLine("ST: " + i);
            }
        }, token);
        return t;
    }
    static void Main()
    {
        CancellationTokenSource cts = new CancellationTokenSource();

        // MT starts ST with the Help of Task that internally send request to ThreadPool
        // threadpool threads are background thread

        // register a lmbda to know that task is over
        Task IncompleteTask= Fun1Async(cts.Token);


        IncompleteTask.ContinueWith(ct =>
        {
            if (ct.IsCanceled)
                Console.WriteLine("Task Over: Cancelled");
            else if (ct.IsFaulted)
                Console.WriteLine("Task Over: Faulted");
            else if (ct.IsCompleted)
                Console.WriteLine("Task Over: Completed");
        });




        while (true) // MT
        {
            string input = Console.ReadLine(); // in GUI instead of this Message Loop runs
            if (input == "stop")
            {
                cts.Cancel();
            }
        }
    } // MT returns to CLR without waiting for ST to complete its operation and CLR kills the app
}
