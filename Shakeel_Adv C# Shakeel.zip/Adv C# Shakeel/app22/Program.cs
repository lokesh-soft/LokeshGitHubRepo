﻿using System;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        // Compute-bound Task
        Task parentTask = new Task(() =>
        {
            var childTask1 = new Task(() => { Console.WriteLine("Child Task1"); }, TaskCreationOptions.AttachedToParent);
            var childTask2 = new Task(() => { Console.WriteLine("Child Task2"); }, TaskCreationOptions.AttachedToParent);

            childTask1.Start();
            childTask2.Start();
        });

        parentTask.ContinueWith(completedTask =>
        {
            Console.WriteLine("Parent Task Completed");
        }, TaskContinuationOptions.OnlyOnRanToCompletion);

        parentTask.Start(); // get the thread from the thread pool


        Console.ReadLine();
    }
}
