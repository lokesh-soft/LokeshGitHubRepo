﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main()
        {
            //int[] numbers = {18, 16, 14, 12, 8, 7, 10};
            ////Console.WriteLine(numbers.All(n=>n%2==0));
            ////Console.WriteLine(numbers.Any(n => n % 2 == 0));

            //var query = numbers.TakeWhile(x => x!= 12);
            //foreach (var VARIABLE in query)
            //{
            //    Console.WriteLine(VARIABLE);
            //}

            object[] arr = {12, "Hello", DateTime.Now};

            //Console.WriteLine(arr.OfType<string>().Any());
            foreach (var item in  arr.OfType<string>().Select(t=>t))
            {
                Console.WriteLine(item.ToString());
            }
                  
        }
    }

