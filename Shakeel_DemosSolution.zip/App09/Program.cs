﻿using System;
using System.Collections;
using System.Collections.Generic;
class Program
{
    static IEnumerable<int> Numbers()
    {
        return new Numbers_0();

        //System.Console.WriteLine("Before 10");
        //yield return 10;
        //System.Console.WriteLine("After 10");

        //System.Console.WriteLine("Before 20");
        //yield return 20;
        //System.Console.WriteLine("After 20");

        //System.Console.WriteLine("Before 30");
        //yield return 30;
        //System.Console.WriteLine("After 30");

    }

    // by CSC
    // collection // State Machine Class : whose object is good in remembering state
    class Numbers_0 : IEnumerable<int>, IEnumerator<int>
    {
        private int state = 0, current;

        // IEnumerable methods
        /* .net 2.0 and later */
        public IEnumerator<int> GetEnumerator()
        {
            state = 1;
            return this;
        }

        // non-generic /* .net 1.0 and 1.1 */ => backward compatibiltiy
        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new System.NotImplementedException();
        }


        // IEnumerator methods
        public bool MoveNext()
        {
            switch (state)
            {
                case 1:
                    System.Console.WriteLine("Before 10");
                    current = 10;
                    state = 2;
                    return true;
                case 2:
                    System.Console.WriteLine("After 10");
                    System.Console.WriteLine("Before 20");
                    current = 20;
                    state = 3;
                    return true;
                case 3:
                    System.Console.WriteLine("After 20");
                    System.Console.WriteLine("Before 30");
                    current = 30;
                    state = 4;
                    return true;
                case 4:
                    System.Console.WriteLine("After 30");
                    state = 0;
                    return false;
                default:
                    return false;
            }
        }

        public int Current
        {
            get { return current; }
        }

        public void Dispose()
        {

        }

        // for backward comtability
        object IEnumerator.Current
        {
            get { throw new System.NotImplementedException(); }
        }


        public void Reset()
        {
            throw new System.NotImplementedException();
        }
    }


    static IEnumerable<int> Numbers2()
    {
        return new Numbers2_0();
        //Console.WriteLine("Before 10");
        //yield return 10;
        //Console.WriteLine("After 10");
        //for (int i = 11; i <= 15; i++)
        //{
        //    Console.WriteLine("Before " + i);
        //    yield return i;
        //    Console.WriteLine("After " + i);
        //}
    }

    class Numbers2_0 : IEnumerable<int>, IEnumerator<int>
    {
        public IEnumerator<int> GetEnumerator()
        {
            state = 1;
            return this;
        }

        int state = 0, current, i = 11;

        public bool MoveNext()
        {
            switch (state)
            {
                case 1:
                    Console.WriteLine("Before 10");
                    current = 10;
                    state = 2;
                    return true;

                case 2:
                    Console.WriteLine("After 10");
                    state = 3;
                    goto gg;

                case 3:
            gg:
                    if (i <= 15)
                    {
                        Console.WriteLine("Before " + i);
                        current = i;
                        state = 4;
                       
                        return true;
                    }
                    else
                        return false;

                case 4:
                    Console.WriteLine("After " + i);
                    i++;
                    state = 3;
                    return true;

                default:
                    return false;
            }
        }

        public int Current
        {
            get { return current; }
        }

        public void Dispose()
        {
        }


        IEnumerator IEnumerable.GetEnumerator()
        {
            return this;
        }

        object IEnumerator.Current
        {
            get { throw new NotImplementedException(); }
        }


        public void Reset()
        {
        }
    }


    static void Main()
    {
        IEnumerable<int> en = Numbers2();
        Console.WriteLine("Before Foreach: ");
        foreach (int item in en)
            Console.WriteLine("Foreach: " + item);

        //IEnumerable<int> en = Numbers();
        //foreach (int item in Numbers())
        //    System.Console.WriteLine("Inside foreach : " + item);

        // expansion of foreach by CSC
        //IEnumerable<int> en = Numbers();
        //IEnumerator<int> et = en.GetEnumerator();
        //while (et.MoveNext())
        //{
        //    int item = et.Current;
        //    System.Console.WriteLine("Inside foreach : " + item);
        //}
    }
}