﻿using System;
using System.Linq.Expressions;

class Program
{
    static void Main()
    {
        // 1st Lambda : function and its address gets stored in delegate object
        Action<int> a1 = i => Console.WriteLine(i);
        // a1 refers to the delegate object

        // 2nd Lambda : function and its address gets stored in delegate object
        Func<int, int, int> a2 = (i, j) => i + j;
        // a2 refers to the delegate object

        a1(100); // calling the 1st Lambda
        // delegate object will call the lambda function

        Console.WriteLine(a2(100, 200)); // calling the 2nd Lambda
        // delegate object will call the lambda function

        // Lambda : Expression Tree (C# code is parsed into Tree Data Stucture)
        Expression<Func<int, int, int>> a3 = (i, j) => i + j;
        // a3 refers to the Expression Tree

        // Traversing the C# Code Tree Data Structure
        Console.WriteLine("Number of Paramters: " + a3.Parameters.Count);
        Console.WriteLine("Paramter #1: " + a3.Parameters[0]);
        Console.WriteLine("Paramter #2: " + a3.Parameters[1]);
        Console.WriteLine("Body: " + a3.Body);
        Console.WriteLine("Body: " + a3.Body.NodeType);

        Console.WriteLine(a3.Compile()(500, 600)); // Expression Tree => MSIL

        //Expression.Variable(typeof(int), "a");
        //Expression.Variable(typeof(int), "b");
        //Expression.Assign(, 10);
        //Expression.Assign(, 20);
        //Expression.Add();
        //Expression.Call()

        // By Visiting this tree SQL queries can be generated
        // Which is done by and Object of a DbSet<> class
        // DbSet<> inherits IQueryable<>
        // When C# compiled encounter any object after "in" in the LINQ
        // query that implements IQueryable it converts all the lambdas to
        // Expression Tree 
        // DbSet will convert expression tree to SQL
        // EF contains DbSet

    }
}