﻿using System;
using System.Collections.Generic;

namespace abb
{
    [Serializable]
    public sealed class Stack<T>
    {
        private T[] items = new T[100];
        private int top = 0;

        public void Push(T item )
        {
            if (top < items.Length)
            {
                items[top] = item;
                top++;
            }
            else
            {
                throw new StackFullException("");
            }
        }

        public T Pop()
        {
            if (top > 0)
            {
                top--;
                return items[top];
            }
            else
                throw new StackEmptyException("");
        }
    }
}
class Program
{
    static void Main()
    {

    }
}
