﻿using System;
class Program
{
    static Tuple<int, int> F1()
    {
        return Tuple.Create( 2015, 11 );
    }

    static Tuple<int,int> F2()
    {
        return Tuple.Create(11, 25);
    }

    static Tuple<int, int, int> F3() 
    {
        return Tuple.Create(2015, 11, 25);

    }

    static Tuple<int, int, int, int> F4() 
    {
        return Tuple.Create(2015, 11, 25, 12);
    }
    
    /// <summary>
    /// year, month, day, hour, minute, dayname
    /// </summary>
    /// <returns>Tuple Object</returns>
    static Tuple<int, int, int, int, int, string> F5() 
    {
        return Tuple.Create(2015, 11, 25, 12, 20, "Wed");
    }

 
    static void Main()
    {
        var t1 = F5();

        var yr = t1.Item1; // year
        var mn = t1.Item2; // month
        var dy = t1.Item3; // day
    }
}