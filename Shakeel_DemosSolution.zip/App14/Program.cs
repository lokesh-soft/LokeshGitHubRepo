﻿using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Threading.Tasks;
using System.Windows.Forms;
class Program
{
    static void Main()
    {
        Form f = new Form();

        Button b = new Button();
        b.Text = "Get Data";
        f.Controls.Add(b);

        TextBox t1 = new TextBox();
        t1.Multiline = true;
        t1.Location = new Point(10, 40);
        t1.Size = new Size(400, 600);
        f.Controls.Add(t1);

        TextBox t2 = new TextBox();
        t2.Multiline = true;
        t2.Location = new Point(410, 40);
        t2.Size = new Size(400, 600);
        f.Controls.Add(t2);

        f.AutoSize = true;

        b.Click += async (sender, args) =>
            {
                Stopwatch sw = Stopwatch.StartNew();

                WebClient http1 = new WebClient();
                Task<string> html1task =  http1.DownloadStringTaskAsync("Http://www.microsoft.com");
               
                WebClient http2 = new WebClient();
                Task<string> html2task = http2.DownloadStringTaskAsync("http://www.google.com");

                await Task.WhenAll(html1task, html2task);

                t1.Text = html1task.Result;
                t2.Text = html2task.Result;
                
                f.Text = sw.ElapsedMilliseconds.ToString();
                sw.Stop();
            };

        f.ShowDialog();
    }
}