﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Drawing; // extension methods
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

[Serializable] // for binary serialization
sealed public class BooksReadException : Exception
{
    public BooksReadException(string message)
        : base(message)
    {
    }
}

[Serializable] // for binary serialization
public sealed class Book
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string Author { get; set; }
}

// represent whole Database
// helps in opening and closing the connection
// transaction
public sealed class BooksContext : DbContext // EF
{
    public BooksContext()
        : base("mycon")
    {
    }
    public DbSet<Book> Books { get; set; } // represents Table
}

sealed class BooksDAL
{
    public List<Book> GetBooks2(int skip, int take)
    {
        BooksContext db = new BooksContext();

        db.Database.Log = logmessage => Console.WriteLine(logmessage);

        //var query =  db.Books.Where(b=>b.Author=="A2").OrderBy(b=>b.Id).Skip(skip).Take(take);

        // preparing the query
        var query = (from book in db.Books
                     where book.Author == "A2"
                     orderby book.Id
                     select book).Skip(skip).Take(take);

        //db.Database.Connection.Open();
        //Console.WriteLine(db.Database.Connection.State);
        var books = query.ToList(); // executing the query
        //Console.WriteLine(db.Database.Connection.State);
        //db.Database.Connection.Close();

        return books;
    }
    public List<Book> GetBooks2() // MT
    {
        BooksContext db = new BooksContext();
        return db.Books.ToList(); // MT
    }

    // this function will be converted State Machine class
    public async Task<List<Book>> GetBooks2Async() // MT
    {
        return await Task<List<Book>>.Run( async () =>
            {
                BooksContext db = new BooksContext(); // MT getting blocked here
                List<Book> books = await db.Books.ToListAsync(); // MT

                // More Work that needs processor

                return books;
            });
    }

    public async Task<List<Book>> GetBooks1Async()
    {
        // read connection string  from config file
        string con = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;

        // ADO.NET
        SqlConnection connection = new SqlConnection(con);

        // preparing the query
        SqlCommand command = new SqlCommand();
        command.CommandText = "SELECT * from Books ORDER BY Id ASC OFFSET 2 ROWS FETCH NEXT 2 ROWS ONLY"; // select only some rows
        command.Connection = connection;

        List<Book> books = new List<Book>();

        try
        {
            await connection.OpenAsync(); // can throw exception
            SqlDataReader reader = await command.ExecuteReaderAsync(); // throw exception // firing the query
            while (await reader.ReadAsync()) // 1 record a time
            {
                await Task.Delay(2000);
                Book book = new Book()
                {
                    Id = (int)reader["Id"],
                    Title = (string)reader["Title"],
                    Author = (string)reader["Author"],
                };
                books.Add(book);
            }
            return books;
        }
        catch (SqlException ex)
        {
            // TODO: Log the exception in the file
            throw new BooksReadException(ex.Message); // rethrowing
        }
        finally
        {
            connection.Close(); // this doesn't throw exception
        }
    }

    public List<Book> GetBooks1()
    {
        // read connection string  from config file
        string con = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;

        // ADO.NET
        SqlConnection connection = new SqlConnection(con);

        // preparing the query
        SqlCommand command = new SqlCommand();
        command.CommandText = "SELECT * from Books ORDER BY Id ASC OFFSET 2 ROWS FETCH NEXT 2 ROWS ONLY"; // select only some rows
        command.Connection = connection;

        List<Book> books = new List<Book>();

        try
        {
            connection.Open(); // can throw exception
            SqlDataReader reader = command.ExecuteReader(); // throw exception // firing the query
            while (reader.Read()) // 1 record a time
            {
                Book book = new Book()
                {
                    Id = (int)reader["Id"],
                    Title = (string)reader["Title"],
                    Author = (string)reader["Author"],
                };
                books.Add(book);
            }
            return books;
        }
        catch (SqlException ex)
        {
            // TODO: Log the exception in the file
            throw new BooksReadException(ex.Message); // rethrowing
        }
        finally
        {
            connection.Close(); // this doesn't throw exception
        }
    }
}
class Program
{
    static void Main()
    {

        Form f = new Form();
        Button b = new Button();
        b.Text = "Get Data";
        f.Controls.Add(b);

        BooksDAL dal = new BooksDAL();

        DataGrid dg = new DataGrid();
        dg.Location = new Point(10, 100);
        dg.Size = new Size(400, 400);

        f.AutoSize = true;

        f.Controls.Add(dg);

        b.Click += async (sender, args) => // MT
            {
                dg.DataSource = await dal.GetBooks2Async(); // MT
            };


        f.ShowDialog();
        //BooksDAL dal = new BooksDAL();
        //try
        //{
        //    List<Book> books = dal.GetBooks2(2,2);
        //    foreach (var book in books)
        //    {
        //        Console.WriteLine(book.Title);
        //    }
        //}
        //catch (BooksReadException ex)
        //{
        //    Console.WriteLine(ex.Message); // display to the user
        //}

        // More work

    }
}