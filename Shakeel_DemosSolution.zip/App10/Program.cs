﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Data.SqlClient; // comes with extension methods written by MS

//static class MyExtensions
//{
//    // class Where_0 : IEnumerable<int>, IEnumerator<int> { GetEnumerator() { } MoveNext() { }, Current { get { } } }  
//    public static IEnumerable<T> Where<T>(this IEnumerable<T> collection, Func<T, bool> condition)
//    {
//        // return new Where_0();

//        Console.WriteLine("Where");
//        // MoveNext() will contain this code as 1 state until end of collection
//        // separated: intialization, condition, incrementation
//        foreach (T item in collection)
//            if (condition(item))  // calling the callback function 
//                yield return item; // current value returned by object that implements IEnumerable<> and IEnumerator<> : State Machine Class
//    }

//    // class Select_0 : IEnumerable<int>, IEnumerator<int> { GetEnumerator() { } MoveNext() { }, Current { get { } } }  
//    public static IEnumerable<TReturn> Select<T, TReturn>(this IEnumerable<T> collection, Func<T, TReturn> projection)
//    {
//        // return new Select_0();

//        Console.WriteLine("Select");
//        // MoveNext() will contain this code as 1 state until end of collection
//        // separated: intialization, condition, incrementation
//        foreach (T item in collection)
//            yield return projection(item);
//    }

//    public static List<T> ToList<T>(this IEnumerable<T> collection)
//    {
//        Console.WriteLine("ToList");
//        List<T> list = new List<T>();
//        foreach (T item in collection)
//        {
//            list.Add(item);
//        }
//        return list;
//    }

//    public static double Sum (this IEnumerable<double> collection)
//    {
//        Console.WriteLine("Sum");
//        double sum = 0;
//        foreach (double item in collection)
//        {
//            sum += item;
//        }
//        return sum;
//    }
//}

class Book
{
    public string Title { get; set; }
    public double Price { get; set; }
    public string Author { get; set; }
    public string Publisher { get; set; }
}
class Program
{
    static void Main()
    {


        Book[] books = { 
                           new Book() { Title="T1", Author="A1", Publisher="P1", Price=1000},
                           new Book() { Title="T2", Author="A2", Publisher="P1", Price=2000},
                           new Book() { Title="T3", Author="A2", Publisher="P2", Price=3000}
                       };

        // books.Where( book => book.Author == "A2" && book.Publisher == "P2").Select(book => book.Price);
        IEnumerable<double> query = from book in books
                                    where book.Author == "A2" && book.Publisher == "P2"
                                    select book.Price;

        foreach ( int price in query) // et = query.GetEnumerator(), et.MoveNext()
        { // item = et.Current
            Console.WriteLine(price);
        }

        Console.WriteLine();

        Console.WriteLine(query.Sum());

        Console.WriteLine();

        List<double> prices = query.ToList();

        // array implements IEnumerable<int>
        //int[] numbers = {10, 20, 30, 40, 50, 60, 70};

        // Preparing the query
        //IEnumerable<string> query = numbers.Where(v => v > 30).Select(v => v.ToString());
        //IEnumerable<string> query = from v in numbers
        //                            where v > 30  // condition
        //                            select v.ToString(); // projection

        // 2 objects are created Where object and Select Object
        // query holds reference of Select Object
        // Select holds reference of Where object
        // Where Object holds reference of Array

        // Execute the query
        //foreach ( string item in query)
        //    Console.WriteLine(item);

        // query => Select Object => Where Object => Array Object
        // IEnumerator<string> et = query.GetEnumerator(); // all objects state gets intialized
        // while ( et.MoveNext() ) // => Select:MoveNext => Where:MoveNext => Array:MoveNext
        //     et.Current ; => Select:Current => Where:Current => Array:MoveNext


    }
}