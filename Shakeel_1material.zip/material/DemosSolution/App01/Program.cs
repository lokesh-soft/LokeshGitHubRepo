﻿class Program : System.Object // mscorlib.dll
{
    // CSC marks the Main as the entry point
    // so that CLR calls it
    static void Main()
    {
        int i = 10; // int - System.Int32 struct - mscorlib.dll
        string s = "Hello"; // System.String class - mscorlid.dll
        System.Console.WriteLine(i); // System.Console class - mscorlib.dll
        System.Console.WriteLine(s); // System.Console class - mscorlib.dll
    }
}