﻿using System;
using System.ComponentModel.Composition;
using System.Windows.Forms;

[Export(typeof(Form))]
class MyForm : Form
{
    // this needs reference of factory objects
    [ImportMany]
    public ShapeFactory[] Factories { get; set; }

    public MyForm(/* this = reference of an object */)
    {
        this.Load += MyForm_Load;
    }

    // ShowDialog calls this
    private void MyForm_Load(object sender, EventArgs e)
    {
        ToolBar tb = new ToolBar();
        foreach (ShapeFactory factory in Factories)
        {
            tb.Buttons.Add(factory.GetName());
        }
        this.Controls.Add(tb);
    }
}