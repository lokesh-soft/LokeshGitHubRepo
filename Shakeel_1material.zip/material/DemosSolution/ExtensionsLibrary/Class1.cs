﻿using System.Windows.Forms;
using System.Collections.Generic;
using System.Reflection;

namespace abb
{
    // make it public to be accessible outside the DLL
    public static class MyExtensions // any name
    {
        // when VS sees this before ListView name in the first parameter
        // VS makes it "appear" as part of ListView but it is not part of ListView
        // hence it cannot access private members
        // Extension Method - only C# language - CLR doesn't understand it
        // C# 3.0 - 2008
        public static void DisplayItems<T>(this ListView lv, IEnumerable<T> collection)
        {
            PropertyInfo[] properties = null;

            // at runtime discover properties of the object - reflection
            foreach (T item in collection)
            {
                properties = item.GetType().GetProperties();
                foreach (PropertyInfo pi in properties) // foreach property create 1 column
                {
                    lv.Columns.Add(pi.Name);
                }
                break;
            }

            if (properties != null) // defensive
            {
                foreach (T item in collection) // for each object in the collection
                {
                    ListViewItem li = null;
                    foreach (PropertyInfo pi in properties) // for each property get value from the object
                    {
                        if (li == null)
                        {
                            li = new ListViewItem();
                            li.Text = pi.GetValue(item).ToString(); // data in the first column
                            lv.Items.Add(li); // add list view item to list view
                        }
                        else
                        {
                            li.SubItems.Add(pi.GetValue(item).ToString()); // data for other columns
                        }
                    }
                }
            }
        }
    }
}
