﻿using System.Drawing;
using System.Windows.Forms;

class MyForm : Form
{
    TextBox filename = new TextBox();
    Button start = new Button();
    Button stop = new Button();
    Label folder = new Label();
    ListBox foundfolder = new ListBox();

    public MyForm()
    {
        this.Controls.Add(filename);
        this.Controls.Add(start);
        this.Controls.Add(stop);
        this.Controls.Add(folder);
        this.Controls.Add(foundfolder);

        filename.Location = new Point(10, 10);
        start.Location = new Point(10, 50);
        stop.Location = new Point(150, 50);
        folder.Location = new Point(10, 100);
        foundfolder.Location = new Point(10, 150);

        filename.Size = new Size(200, 30);
        folder.Size = new Size(800, 30);
        foundfolder.Size = new Size(800, 300);

        start.Text = "Start";
        stop.Text = "Stop";

        this.AutoSize = true;

        stop.Enabled = false;

        start.Click += Start_Click;
        stop.Click += Stop_Click;
    }

    private void Stop_Click(object sender, System.EventArgs e)
    {
        stop.Enabled = false;
        start.Enabled = true;
    }

    private void Start_Click(object sender, System.EventArgs e)
    {
        stop.Enabled = true;
        start.Enabled = false;
    }
}
class Program
{
    static void Main()
    {
        MyForm f = new MyForm();
        f.ShowDialog();
    }
}